<?php
/**
 * Masher Hisab website: automatic updates.
 *
 * Put this one file in the masherhisab.rabbyhossain.com folder.
 *
 * GET  deploy.php?pull=1&sha=<commit>
 *      Downloads the official build from the public masher-hisab-updates
 *      repository (branch "web", or that exact commit) and installs it.
 *      GitHub Actions calls this after every build. It can only ever install
 *      the official build, so it needs no password.
 * POST deploy.php (optional, signed with deploy-key.php)
 *      Headers X-Deploy-Time and X-Deploy-Signature = hex HMAC-SHA256 of
 *      "<time>.<sha256 of body>".
 */
declare(strict_types=1);

const MAX_SKEW = 300;            // seconds
const MAX_BYTES = 60 * 1048576;  // 60 MB
const ROOT = __DIR__;
const BLOCK_BEGIN = '# BEGIN Masher Hisab web app';
const BLOCK_END = '# END Masher Hisab web app';
const PULL_REPO = 'rabbyhossain2927/masher-hisab-updates';
const PULL_FILE = 'masher-hisab-web.zip';
const PULL_BRANCH = 'web-test';

header('Content-Type: application/json');
header('Cache-Control: no-store');

function out(array $d, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($d);
    exit;
}

function fetch_url(string $url): ?string
{
    if (function_exists('curl_init')) {
        $c = curl_init($url);
        curl_setopt_array($c, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => 240,
            CURLOPT_USERAGENT => 'MasherHisabDeploy/1',
        ]);
        $data = curl_exec($c);
        $code = (int) curl_getinfo($c, CURLINFO_HTTP_CODE);
        curl_close($c);
        return ($data !== false && $code === 200) ? (string) $data : null;
    }
    $ctx = stream_context_create(['http' => ['timeout' => 240, 'header' => "User-Agent: MasherHisabDeploy/1\r\n"]]);
    $data = @file_get_contents($url, false, $ctx);
    return $data === false ? null : $data;
}

$method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
$pull = isset($_GET['pull']);

if ($method !== 'POST' && !$pull) {
    $state = is_file(ROOT . '/.deploy-tmp/state.json') ? json_decode((string) file_get_contents(ROOT . '/.deploy-tmp/state.json'), true) : null;
    out(['ok' => true, 'app' => 'Masher Hisab web deploy', 'zip' => class_exists('ZipArchive'), 'last' => $state]);
}

if ($pull) {
    // At most one pull every 30 seconds.
    $lock = ROOT . '/.deploy-tmp/last-pull';
    @mkdir(ROOT . '/.deploy-tmp', 0755, true);
    if (is_file($lock) && time() - (int) @filemtime($lock) < 30) {
        out(['ok' => false, 'error' => 'too_soon'], 429);
    }
    @touch($lock);
    $sha = (string) ($_GET['sha'] ?? '');
    $ref = preg_match('/^[0-9a-f]{40}$/', $sha) ? $sha : PULL_BRANCH;
    $body = fetch_url('https://raw.githubusercontent.com/' . PULL_REPO . '/' . $ref . '/' . PULL_FILE);
    if ($body === null || strlen($body) < 1000) {
        out(['ok' => false, 'error' => 'download_failed', 'ref' => $ref], 502);
    }
    $_SERVER['HTTP_X_DEPLOY_VERSION'] = (string) ($_GET['v'] ?? $ref);
    goto install;
}

$keyFile = ROOT . '/deploy-key.php';
$key = is_file($keyFile) ? (string) (require $keyFile) : '';
if (strlen($key) < 32) {
    out(['ok' => false, 'error' => 'deploy_disabled'], 403);
}

$len = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($len <= 0 || $len > MAX_BYTES) {
    out(['ok' => false, 'error' => 'bad_size', 'bytes' => $len], 413);
}
$body = (string) file_get_contents('php://input');
$time = (string) ($_SERVER['HTTP_X_DEPLOY_TIME'] ?? '');
$sig = strtolower((string) ($_SERVER['HTTP_X_DEPLOY_SIGNATURE'] ?? ''));
if (!ctype_digit($time) || abs(time() - (int) $time) > MAX_SKEW) {
    out(['ok' => false, 'error' => 'stale'], 401);
}
$expect = hash_hmac('sha256', $time . '.' . hash('sha256', $body), $key);
if (!hash_equals($expect, $sig)) {
    out(['ok' => false, 'error' => 'bad_signature'], 401);
}
install:
if (!class_exists('ZipArchive')) {
    out(['ok' => false, 'error' => 'zip_extension_missing'], 500);
}

/** Files we never write or delete. */
function protected_path(string $rel): bool
{
    if ($rel === '' || str_contains($rel, '..') || str_contains($rel, "\0") || $rel[0] === '/' || str_contains($rel, '\\')) {
        return true;
    }
    return (bool) preg_match('#^(deploy\.php|deploy-key\.php|\.deploy|\.well-known/|cgi-bin/|error_log|php\.ini|\.user\.ini)#', $rel);
}

function rmdir_all(string $dir): void
{
    if (!is_dir($dir)) {
        return;
    }
    $it = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dir, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($it as $f) {
        $f->isDir() ? @rmdir($f->getPathname()) : @unlink($f->getPathname());
    }
    @rmdir($dir);
}

/** Keeps cPanel's own lines in .htaccess and swaps only our block. */
function merge_htaccess(string $new): string
{
    $file = ROOT . '/.htaccess';
    $old = is_file($file) ? (string) file_get_contents($file) : '';
    $old = preg_replace('#\n?' . preg_quote(BLOCK_BEGIN, '#') . '.*?' . preg_quote(BLOCK_END, '#') . '\n?#s', "\n", $old) ?? $old;
    $new = trim($new);
    if (!str_contains($new, BLOCK_BEGIN)) {
        $new = BLOCK_BEGIN . "\n" . $new . "\n" . BLOCK_END;
    }
    return rtrim($old) . "\n\n" . $new . "\n";
}

$tmpRoot = ROOT . '/.deploy-tmp';
@mkdir($tmpRoot, 0755, true);
@file_put_contents($tmpRoot . '/.htaccess', "Require all denied\nDeny from all\n");
$zipFile = $tmpRoot . '/release.zip';
file_put_contents($zipFile, $body);
unset($body);

$zip = new ZipArchive();
if ($zip->open($zipFile) !== true) {
    out(['ok' => false, 'error' => 'bad_zip'], 400);
}
$stage = $tmpRoot . '/stage-' . bin2hex(random_bytes(4));
@mkdir($stage, 0755, true);
$files = [];
$htaccess = null;
for ($i = 0; $i < $zip->numFiles; $i++) {
    $name = (string) $zip->getNameIndex($i);
    if (str_ends_with($name, '/')) {
        continue;
    }
    $rel = str_starts_with($name, './') ? substr($name, 2) : $name;
    if (protected_path($rel)) {
        continue;
    }
    $data = $zip->getFromIndex($i);
    if ($data === false) {
        $zip->close();
        rmdir_all($stage);
        out(['ok' => false, 'error' => 'read_failed', 'file' => $rel], 500);
    }
    if ($rel === '.htaccess') {
        $htaccess = $data;
        continue;
    }
    $dest = $stage . '/' . $rel;
    @mkdir(dirname($dest), 0755, true);
    file_put_contents($dest, $data);
    $files[] = $rel;
}
$zip->close();
@unlink($zipFile);

if (!in_array('index.html', $files, true) || !in_array('main.dart.js', $files, true)) {
    rmdir_all($stage);
    out(['ok' => false, 'error' => 'incomplete_release'], 400);
}

// index.html last, so a half-copied update never loads.
usort($files, fn($a, $b) => ($a === 'index.html') <=> ($b === 'index.html'));
$copied = 0;
foreach ($files as $rel) {
    $dest = ROOT . '/' . $rel;
    @mkdir(dirname($dest), 0755, true);
    $tmp = $dest . '.deploy-tmp';
    if (!@copy($stage . '/' . $rel, $tmp) || !@rename($tmp, $dest)) {
        @unlink($tmp);
        rmdir_all($stage);
        out(['ok' => false, 'error' => 'write_failed', 'file' => $rel, 'copied' => $copied], 500);
    }
    @chmod($dest, 0644);
    $copied++;
}
if ($htaccess !== null) {
    file_put_contents(ROOT . '/.htaccess', merge_htaccess($htaccess));
}

// Remove files from the previous update that are gone now.
$manifest = $tmpRoot . '/manifest.json';
$old = is_file($manifest) ? (json_decode((string) file_get_contents($manifest), true) ?: []) : [];
$removed = 0;
foreach (array_diff($old, $files) as $rel) {
    if (is_string($rel) && !protected_path($rel) && is_file(ROOT . '/' . $rel)) {
        @unlink(ROOT . '/' . $rel);
        $removed++;
    }
}
file_put_contents($manifest, json_encode(array_values($files)));
rmdir_all($stage);

$result = ['ok' => true, 'files' => $copied, 'removed' => $removed, 'version' => (string) ($_SERVER['HTTP_X_DEPLOY_VERSION'] ?? ''), 'at' => date('c')];
@file_put_contents($tmpRoot . '/state.json', json_encode($result));
out($result);
