<?php
// Masher Hisab admin panel — masherhisab.rabbyhossain.com/rabbyadmin
declare(strict_types=1);

require __DIR__ . '/inc/boot.php';

$api = ra_api_dir();
if ($api === null) {
    http_response_code(500);
    echo '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Admin setup</title>'
        . '<link rel="stylesheet" href="assets/admin.css"><div class="center"><div class="auth"><div class="card stack"><h1>Almost there</h1>'
        . '<p>The panel could not find the <b>masher-api</b> folder (it has the database details).</p>'
        . '<p class="muted">In cPanel → File Manager, make a file <code>rabbyadmin/config.local.php</code> here with:</p>'
        . '<pre style="white-space:pre-wrap;background:#FAFCFB;border:1px solid #DDE6E1;border-radius:10px;padding:10px">&lt;?php return [\'api_dir\' =&gt; \'/home/YOUR-CPANEL-USER/public_html/masher-api\'];</pre>'
        . '<p class="muted small">Use the real path to the folder that has api.php and config.php.</p></div></div></div>';
    exit;
}
define('RA_API', $api);

require RA_API . '/lib.php';
require __DIR__ . '/inc/totp.php';
require __DIR__ . '/inc/data.php';
require __DIR__ . '/inc/backup.php';
require __DIR__ . '/inc/server.php';
require __DIR__ . '/inc/views.php';
require __DIR__ . '/inc/auth.php';
require __DIR__ . '/inc/actions.php';
require __DIR__ . '/inc/pages.php';

ra_session_start();
ra_schema();

$p = (string) ($_GET['p'] ?? 'dashboard');

if ($p === 'logout') {
    if (ra_admin()) {
        ra_log('logout');
    }
    $_SESSION = [];
    session_destroy();
    ra_redirect('./');
}

$hasAdmin = (int) db()->query('SELECT COUNT(*) FROM mh_admins')->fetchColumn() > 0;
if (!$hasAdmin) {
    ra_setup();
    exit;
}
if (!ra_admin()) {
    ra_login();
    exit;
}
if ($p === 'recovery') {
    ra_recovery_page();
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!ra_csrf_ok()) {
        ra_flash('Your session expired. Please try again.', 'bad');
        ra_redirect('./');
    }
    ra_handle_post();
}

switch ($p) {
    case 'users':
        ra_page_users();
        break;
    case 'user':
        ra_page_user();
        break;
    case 'licenses':
        ra_page_licenses();
        break;
    case 'backups':
        ra_page_backups();
        break;
    case 'log':
        ra_page_log();
        break;
    case 'settings':
        ra_page_settings();
        break;
    default:
        ra_page_dashboard();
}
