<?php
// Masher Hisab admin panel: keeps the masher-api files up to date.
// Each website update ships the newest API files in rabbyadmin/server-files
// (named .src so they can never run from there). "Update server" copies
// them into masher-api, keeping a copy of the old ones. config.php is never touched.
declare(strict_types=1);

const RA_SERVER_FILES = ['api.php', 'lib.php', 'share.php', 'backup.php', 'cron.php', 'admin.php', 'index.php'];

function ra_server_src(string $name): string
{
    return RA_ROOT . '/server-files/' . preg_replace('/\.php$/', '.src', $name);
}

/** [name => 'same' | 'changed' | 'missing' | 'no-source'] */
function ra_server_status(): array
{
    $out = [];
    foreach (RA_SERVER_FILES as $f) {
        $src = ra_server_src($f);
        $dst = RA_API . '/' . $f;
        if (!is_file($src)) {
            $out[$f] = 'no-source';
        } elseif (!is_file($dst)) {
            $out[$f] = 'missing';
        } else {
            $out[$f] = hash_file('sha256', $src) === hash_file('sha256', $dst) ? 'same' : 'changed';
        }
    }
    return $out;
}

function ra_server_needs_update(): bool
{
    foreach (ra_server_status() as $s) {
        if ($s === 'changed' || $s === 'missing') {
            return true;
        }
    }
    return false;
}

/** Copies the new files in. Returns [count, backup folder]. */
function ra_server_update(): array
{
    $stamp = date('Y-m-d-His');
    $keep = RA_API . '/cache/old-files/' . $stamp;
    @mkdir($keep, 0755, true);
    @file_put_contents(RA_API . '/cache/old-files/.htaccess', "Require all denied\nDeny from all\n");
    $n = 0;
    foreach (ra_server_status() as $f => $s) {
        if ($s !== 'changed' && $s !== 'missing') {
            continue;
        }
        $src = ra_server_src($f);
        $code = (string) file_get_contents($src);
        if (!str_starts_with($code, '<?php')) {
            throw new RuntimeException("$f in the update looks wrong, so nothing was changed for it.");
        }
        $dst = RA_API . '/' . $f;
        if (is_file($dst)) {
            @copy($dst, "$keep/$f");
        }
        $tmp = "$dst.new";
        if (@file_put_contents($tmp, $code) === false || !@rename($tmp, $dst)) {
            @unlink($tmp);
            throw new RuntimeException("Could not write $f. Check the folder permissions of masher-api.");
        }
        @chmod($dst, 0644);
        $n++;
    }
    if (function_exists('opcache_reset')) {
        @opcache_reset();
    }
    return [$n, $keep];
}
