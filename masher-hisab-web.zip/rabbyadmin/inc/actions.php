<?php
// Masher Hisab admin panel: every button that changes something.
declare(strict_types=1);

function ra_back(): void
{
    $to = (string) ($_POST['back'] ?? '');
    ra_redirect(preg_match('/^\?[A-Za-z0-9_=&%.\-@+]*$/', $to) ? $to : './');
}

function ra_handle_post(): void
{
    $do = (string) ($_POST['do'] ?? '');
    $uid = (string) ($_POST['uid'] ?? '');
    $key = ra_key((string) ($_POST['key'] ?? ''));
    $user = $uid !== '' ? ra_user($uid) : null;
    $who = $user ? ($user['email'] ?: $user['uid']) : $uid;

    try {
        switch ($do) {
            // ---------------------------------------------------- users
            case 'trial_extend':
                if ($user) {
                    $days = max(-365, min(365, (int) ($_POST['days'] ?? 0)));
                    ra_trial_shift($uid, $days);
                    ra_log('trial_extend', $who, ($days >= 0 ? '+' : '') . "$days days");
                    ra_flash(($days >= 0 ? "Added $days trial day(s)" : "Took " . abs($days) . " day(s) off the trial") . " for $who.");
                }
                break;
            case 'trial_reset':
                if ($user) {
                    ra_trial_set($uid, now_ms());
                    ra_log('trial_reset', $who);
                    ra_flash("Trial started again (7 days) for $who.");
                }
                break;
            case 'trial_end':
                if ($user) {
                    ra_trial_set($uid, now_ms() - (RA_TRIAL_DAYS + 1) * 86400000);
                    ra_log('trial_end', $who);
                    ra_flash("Trial ended for $who.");
                }
                break;
            case 'give_license':
                if ($user) {
                    $k = ra_give_license($user, trim((string) ($_POST['note'] ?? '')));
                    ra_log('give_license', $who, $k);
                    ra_flash("Free license $k given to $who. It reaches their phones on the next sync (app MH 13.6.3 or newer).");
                }
                break;
            case 'remove_license':
                if ($user) {
                    $k = ra_remove_license($uid);
                    ra_log('remove_license', $who, (string) $k);
                    ra_flash($k ? "License $k removed from $who." : 'This account has no license.');
                }
                break;
            // ---------------------------------------------------- licenses
            case 'key_create':
                $n = max(1, min(100, (int) ($_POST['count'] ?? 1)));
                $keys = ra_create_keys($n, trim((string) ($_POST['note'] ?? '')));
                $_SESSION['new_keys'] = $keys;
                ra_log('key_create', count($keys) . ' key(s)', trim((string) ($_POST['note'] ?? '')));
                ra_flash('Created ' . count($keys) . ' key(s). They work in the app from MH 13.6.3.');
                break;
            case 'key_deactivate':
                if ($key !== '') {
                    $n = ra_revoke_key($key);
                    ra_log('key_deactivate', $key, "$n account(s)");
                    ra_flash($n ? "$key removed from $n account(s). It can be activated again." : "$key is not active on any account.");
                }
                break;
            case 'key_block':
                if ($key !== '') {
                    $n = ra_block_key($key, trim((string) ($_POST['reason'] ?? '')));
                    ra_log('key_block', $key, trim((string) ($_POST['reason'] ?? '')));
                    ra_flash("$key is blocked" . ($n ? " and was removed from $n account(s)." : '.'));
                }
                break;
            case 'key_unblock':
                if ($key !== '') {
                    ra_unblock_key($key);
                    ra_log('key_unblock', $key);
                    ra_flash("$key is unblocked.");
                }
                break;
            case 'key_unbind':
                if ($key !== '') {
                    $n = ra_revoke_key($key);
                    db()->prepare("UPDATE mh_licenses SET uid = NULL, email = '', activated = 0 WHERE license_key = ?")->execute([$key]);
                    ra_log('key_unbind', $key);
                    ra_flash("$key is free again and can be used by another account.");
                }
                break;
            case 'key_delete':
                if ($key !== '') {
                    $n = ra_revoke_key($key);
                    db()->prepare('DELETE FROM mh_licenses WHERE license_key = ?')->execute([$key]);
                    db()->prepare('DELETE FROM mh_key_blocks WHERE license_key = ?')->execute([$key]);
                    ra_log('key_delete', $key, "$n account(s)");
                    ra_flash("$key deleted" . ($n ? " and removed from $n account(s)." : '.'));
                }
                break;
            case 'key_note':
                if ($key !== '') {
                    db()->prepare('UPDATE mh_licenses SET note = ? WHERE license_key = ?')
                        ->execute([substr(trim((string) ($_POST['note'] ?? '')), 0, 250), $key]);
                    ra_log('key_note', $key);
                    ra_flash('Note saved.');
                }
                break;

            // ---------------------------------------------------- backups
            case 'backup_make':
                $b = ra_backup_make();
                ra_log('backup_make', $b['name'], $b['rows'] . ' rows');
                ra_flash('Backup saved: ' . $b['name'] . ' (' . ra_num($b['rows']) . ' rows).');
                break;
            case 'backup_locked':
                $pass = (string) ($_POST['pass'] ?? '');
                $fresh = ($_POST['file'] ?? '') === '__now';
                $p = $fresh ? null : ra_backup_path((string) ($_POST['file'] ?? ''));
                if (!$fresh && $p === null) {
                    ra_flash('Backup not found.', 'bad');
                    break;
                }
                if (!ra_lock_ready()) {
                    ra_flash('This server cannot lock files (PHP OpenSSL is missing). Ask your hosting to turn it on.', 'bad');
                    break;
                }
                if (strlen($pass) < 8 || $pass !== (string) ($_POST['pass2'] ?? '')) {
                    ra_flash('Choose a backup password with 8+ characters, the same in both boxes.', 'bad');
                    break;
                }
                @set_time_limit(300);
                if ($fresh) {
                    // Made right now, never left on the server unlocked.
                    $tmp = tempnam(sys_get_temp_dir(), 'mhb');
                    ra_backup_write($tmp);
                    $locked = ra_backup_lock((string) file_get_contents($tmp), $pass);
                    @unlink($tmp);
                    $name = 'masher-backup-' . date('Y-m-d-His') . '.mhdb';
                } else {
                    $locked = ra_backup_lock((string) file_get_contents($p), $pass);
                    $name = preg_replace('/\.sql\.gz$/', '.mhdb', basename($p));
                }
                ra_log('backup_locked_download', $name);
                header('Content-Type: application/octet-stream');
                header('Content-Disposition: attachment; filename="' . $name . '"');
                header('Content-Length: ' . strlen($locked));
                echo $locked;
                exit;
            case 'backup_delete':
                $p = ra_backup_path((string) ($_POST['file'] ?? ''));
                if ($p !== null) {
                    @unlink($p);
                    ra_log('backup_delete', basename($p));
                    ra_flash('Deleted ' . basename($p) . '.');
                }
                break;
            case 'backup_restore':
            case 'backup_upload':
                if (trim((string) ($_POST['confirm'] ?? '')) !== 'RESTORE') {
                    ra_flash('Type RESTORE to confirm.', 'bad');
                    break;
                }
                $tmp = null;
                if ($do === 'backup_upload') {
                    $up = $_FILES['file'] ?? null;
                    if (!$up || (int) $up['error'] !== UPLOAD_ERR_OK || !is_uploaded_file($up['tmp_name'])) {
                        ra_flash('Choose a backup file (.mhdb or .sql.gz) to upload. Big files may need a higher upload limit in cPanel.', 'bad');
                        break;
                    }
                    $src = $up['tmp_name'];
                    $label = (string) $up['name'];
                    if (ra_is_locked($src)) {
                        $tmp = ra_backup_unlock($src, (string) ($_POST['pass'] ?? ''));
                        $src = $tmp;
                    }
                } else {
                    $src = ra_backup_path((string) ($_POST['file'] ?? ''));
                    $label = (string) ($_POST['file'] ?? '');
                    if ($src === null) {
                        ra_flash('Backup not found.', 'bad');
                        break;
                    }
                }
                try {
                    ra_backup_statements($src); // check the whole file before touching anything
                    $safety = ra_backup_make('before-restore');
                    $n = ra_backup_restore($src, !empty($_POST['reload']));
                } finally {
                    if ($tmp !== null) {
                        @unlink($tmp);
                    }
                }
                ra_log('backup_restore', $label, "$n commands; safety copy " . $safety['name']);
                ra_flash("Restored $label. A copy of the data before the restore was saved as " . $safety['name'] . '.');
                break;
            case 'autobackup':
                ra_autobackup_set(!empty($_POST['on']));
                ra_log('autobackup', !empty($_POST['on']) ? 'on' : 'off');
                ra_flash('Daily automatic backup is ' . (!empty($_POST['on']) ? 'on.' : 'off.'));
                break;

            // ---------------------------------------------------- messages
            case 'msg_send':
                if (!function_exists('message_send')) {
                    ra_flash('Tap Update server in Settings first.', 'bad');
                    break;
                }
                $title = trim((string) ($_POST['title'] ?? ''));
                $text = trim((string) ($_POST['body'] ?? ''));
                $details = trim((string) ($_POST['details'] ?? ''));
                $tpl = (string) ($_POST['tpl'] ?? '');
                $tpls = message_templates();
                if ($title === '' && $text === '' && isset($tpls[$tpl])) {
                    [$title, $text, $details] = $tpls[$tpl];
                }
                $push = !empty($_POST['push']);
                $mail = !empty($_POST['mail']);
                $only = strtolower(trim((string) ($_POST['only'] ?? '')));
                if ($only !== '' && !filter_var($only, FILTER_VALIDATE_EMAIL)) {
                    ra_flash('That test email does not look right.', 'bad');
                    break;
                }
                if ($title === '' || $text === '' || (!$push && !$mail)) {
                    ra_flash('Pick a ready-made message or write one, and pick push and/or email.', 'bad');
                    break;
                }
                $_SESSION['msg_test'] = $only;
                @set_time_limit(600);
                [$np, $nm] = message_send('custom', $title, $text, $push, $mail, $only === '' ? null : $only, $details);
                ra_log('message', $title, ($only === '' ? 'everyone' : "test to $only") . ": $np push, $nm email");
                ra_flash(($only === '' ? 'Sent to everyone: ' : "Test sent to $only: ") . "$np phone(s) got the notification, $nm email(s) went out."
                    . ($only !== '' && $np === 0 && $push ? ' (No phone found: open the new app version signed in with that email and allow notifications.)' : ''));
                break;
            case 'fcm_key':
                if (!function_exists('fcm_save_account')) {
                    ra_flash('Tap Update server in Settings first.', 'bad');
                    break;
                }
                $err = fcm_save_account(trim((string) ($_POST['json'] ?? '')));
                ra_log('fcm_key', $err === '' ? 'saved' : 'rejected');
                ra_flash($err === '' ? 'Firebase key saved. Push notifications are ready.' : $err, $err === '' ? 'ok' : 'bad');
                break;
            case 'promo_set':
                if (function_exists('promo_set')) {
                    promo_set(['push' => !empty($_POST['push']), 'mail' => !empty($_POST['mail'])]);
                    ra_log('promo', (!empty($_POST['push']) ? 'push on' : 'push off') . ', ' . (!empty($_POST['mail']) ? 'mail on' : 'mail off'));
                    ra_flash('Automatic tips saved.');
                }
                break;

            // ---------------------------------------------------- settings
            case 'server_update':
                [$n, $keep] = ra_server_update();
                ra_log('server_update', "$n file(s)");
                ra_flash($n ? "Updated $n server file(s). The old ones are kept in masher-api/cache/old-files." : 'Server files are already up to date.');
                break;
            case 'password':
                $a = ra_admin();
                $new = (string) ($_POST['new'] ?? '');
                if (!password_verify((string) ($_POST['current'] ?? ''), $a['pass_hash'])) {
                    ra_add_fail();
                    ra_flash('Your current password is wrong.', 'bad');
                } elseif (strlen($new) < 10 || $new !== (string) ($_POST['new2'] ?? '')) {
                    ra_flash('The new password needs 10+ characters and both boxes must match.', 'bad');
                } elseif (($step = ra_totp_check($a['totp_secret'], (string) ($_POST['code'] ?? ''), (int) $a['totp_last'])) === 0) {
                    ra_add_fail();
                    ra_flash('The 6-digit code is not right.', 'bad');
                } else {
                    db()->prepare('UPDATE mh_admins SET pass_hash = ?, totp_last = ? WHERE id = ?')->execute([password_hash($new, PASSWORD_DEFAULT), $step, $a['id']]);
                    ra_trust_forget((int) $a['id']);
                    ra_log('password_change', $a['username']);
                    ra_flash('Password changed. Remembered devices were forgotten, so each needs the code once more.');
                }
                break;
            case 'recovery_new':
                $a = ra_admin();
                if (($step = ra_totp_check($a['totp_secret'], (string) ($_POST['code'] ?? ''), (int) $a['totp_last'])) === 0) {
                    ra_add_fail();
                    ra_flash('The 6-digit code is not right.', 'bad');
                    break;
                }
                [$plain, $json] = ra_new_recovery();
                db()->prepare('UPDATE mh_admins SET recovery = ?, totp_last = ? WHERE id = ?')->execute([$json, $step, $a['id']]);
                $_SESSION['recovery_show'] = $plain;
                ra_log('recovery_new', $a['username']);
                ra_redirect(ra_url('recovery'));
                // no break
            case 'totp_start':
                $a = ra_admin();
                if (!password_verify((string) ($_POST['current'] ?? ''), $a['pass_hash'])) {
                    ra_add_fail();
                    ra_flash('Your password is wrong.', 'bad');
                    break;
                }
                $_SESSION['new_totp'] = ra_totp_new_secret();
                break;
            case 'totp_finish':
                $a = ra_admin();
                $secret = (string) ($_SESSION['new_totp'] ?? '');
                if ($secret === '' || ($step = ra_totp_check($secret, (string) ($_POST['code'] ?? ''))) === 0) {
                    ra_add_fail();
                    ra_flash('That code is not right. Scan the new QR code and try again.', 'bad');
                    break;
                }
                db()->prepare('UPDATE mh_admins SET totp_secret = ?, totp_last = ? WHERE id = ?')->execute([$secret, $step, $a['id']]);
                unset($_SESSION['new_totp']);
                ra_trust_forget((int) $a['id']);
                ra_log('totp_change', $a['username']);
                ra_flash('Your authenticator app is changed. The old one no longer works.');
                break;
            case 'trust_forget':
                $a = ra_admin();
                $id = (int) ($_POST['id'] ?? 0);
                ra_trust_forget((int) $a['id'], $id);
                ra_log('device_forget', $id > 0 ? "device $id" : 'all devices');
                ra_flash($id > 0 ? 'That device will need the code next time.' : 'All devices will need the code next time.');
                break;
            case 'totp_cancel':
                unset($_SESSION['new_totp']);
                break;
            default:
                ra_flash('Unknown action.', 'bad');
        }
    } catch (RuntimeException $e) {
        ra_flash($e->getMessage(), 'bad');
    } catch (Throwable $e) {
        error_log('rabbyadmin: ' . $e->getMessage());
        ra_flash('Something went wrong: ' . $e->getMessage(), 'bad');
    }
    ra_back();
}
