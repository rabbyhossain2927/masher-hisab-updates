<?php
// Masher Hisab admin panel: reading and changing app data.
declare(strict_types=1);

const RA_SHOP_API = 'https://shop.rabbyhossain.com/api/license';

function ra_json($s): ?array
{
    $d = json_decode((string) $s, true);
    return is_array($d) ? $d : null;
}

function ra_key(string $k): string
{
    return substr(strtoupper(trim($k)), 0, 80);
}

/** Trial / license state from the two root docs. */
function ra_state(?array $license, ?array $trial): array
{
    if ($license !== null) {
        return ['state' => 'licensed', 'label' => 'Licensed', 'left' => null, 'end' => 0];
    }
    $start = isset($trial['start']) && is_numeric($trial['start']) ? (int) $trial['start'] : 0;
    if ($start <= 0) {
        return ['state' => 'new', 'label' => 'No trial yet', 'left' => null, 'end' => 0];
    }
    $end = $start + RA_TRIAL_DAYS * 86400000;
    $leftMs = $end - now_ms();
    if ($leftMs <= 0) {
        return ['state' => 'expired', 'label' => 'Trial ended', 'left' => 0, 'end' => $end];
    }
    $days = (int) ceil($leftMs / 86400000);
    return ['state' => 'trial', 'label' => "Trial · $days day" . ($days === 1 ? '' : 's') . ' left', 'left' => $days, 'end' => $end];
}

function ra_user(string $uid): ?array
{
    $st = db()->prepare('SELECT * FROM mh_users WHERE uid = ?');
    $st->execute([$uid]);
    return $st->fetch() ?: null;
}

function ra_doc(string $uid, string $col, string $id): ?array
{
    $st = db()->prepare('SELECT data, deleted FROM mh_docs WHERE uid = ? AND col = ? AND id = ?');
    $st->execute([$uid, $col, $id]);
    $r = $st->fetch();
    if (!$r || (int) $r['deleted'] === 1) {
        return null;
    }
    return ra_json($r['data']);
}

/**
 * Writes (or with null removes) one doc as the server, so every phone of
 * the account gets it on its next sync.
 */
function ra_put_doc(string $uid, string $col, string $id, ?array $data): void
{
    $pdo = db();
    $pdo->beginTransaction();
    try {
        $st = $pdo->prepare('SELECT stamp FROM mh_users WHERE uid = ? FOR UPDATE');
        $st->execute([$uid]);
        $cur = $st->fetchColumn();
        if ($cur === false) {
            $pdo->rollBack();
            return;
        }
        $stamp = max((int) $cur, now_ms()) + 1;
        $json = $data === null ? '{}' : json_encode($data, JSON_UNESCAPED_UNICODE);
        $pdo->prepare('INSERT INTO mh_docs (uid, col, id, data, updated, deleted) VALUES (?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE data = VALUES(data), updated = VALUES(updated), deleted = VALUES(deleted)')
            ->execute([$uid, $col, $id, $json, $stamp, $data === null ? 1 : 0]);
        $pdo->prepare('UPDATE mh_users SET stamp = ? WHERE uid = ?')->execute([$stamp, $uid]);
        $pdo->commit();
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

/** Accounts that have this key as their license: [uid => license doc]. */
function ra_key_users(string $key): array
{
    $st = db()->prepare("SELECT uid, data FROM mh_docs WHERE col = 'root' AND id = 'license' AND deleted = 0 AND data LIKE ?");
    $st->execute(['%' . str_replace(['\\', '%', '_'], ['\\\\', '\\%', '\\_'], $key) . '%']);
    $out = [];
    foreach ($st->fetchAll() as $r) {
        $d = ra_json($r['data']);
        if ($d !== null && ra_key((string) ($d['key'] ?? '')) === $key) {
            $out[$r['uid']] = $d;
        }
    }
    return $out;
}

/** Frees a phone seat at the shop (best effort). */
function ra_shop_deactivate(string $key, string $device): void
{
    if ($device === '') {
        return;
    }
    $url = RA_SHOP_API . '/deactivate?' . http_build_query(['key' => $key, 'product' => '', 'device' => $device]);
    if (function_exists('curl_init')) {
        $c = curl_init($url);
        curl_setopt_array($c, [CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 10, CURLOPT_USERAGENT => 'MasherHisabAdmin/1']);
        curl_exec($c);
        curl_close($c);
        return;
    }
    @file_get_contents($url, false, stream_context_create(['http' => ['timeout' => 10]]));
}

/** Removes the license from one account (and frees the shop seat). */
function ra_remove_license(string $uid): ?string
{
    $lic = ra_doc($uid, 'root', 'license');
    if ($lic === null) {
        return null;
    }
    $key = ra_key((string) ($lic['key'] ?? ''));
    if (($lic['source'] ?? '') === 'shop') {
        ra_shop_deactivate($key, (string) ($lic['deviceId'] ?? ''));
    }
    ra_put_doc($uid, 'root', 'license', null);
    return $key;
}

/** Removes a key from every account that uses it. Returns how many. */
function ra_revoke_key(string $key): int
{
    $n = 0;
    foreach (ra_key_users($key) as $uid => $lic) {
        ra_remove_license((string) $uid);
        $n++;
    }
    return $n;
}

function ra_new_key(): string
{
    $chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    $parts = [];
    for ($p = 0; $p < 3; $p++) {
        $s = '';
        for ($i = 0; $i < 4; $i++) {
            $s .= $chars[random_int(0, strlen($chars) - 1)];
        }
        $parts[] = $s;
    }
    return 'MH-' . implode('-', $parts);
}

/** Makes Masher Hisab keys (they work in the app from MH 13.6.3). */
function ra_create_keys(int $count, string $note): array
{
    $st = db()->prepare('INSERT IGNORE INTO mh_licenses (license_key, created, note, max_devices) VALUES (?, ?, ?, 99)');
    $keys = [];
    $tries = 0;
    while (count($keys) < $count && $tries++ < $count * 5) {
        $k = ra_new_key();
        $st->execute([$k, now_ms(), substr($note, 0, 250)]);
        if ($st->rowCount() === 1) {
            $keys[] = $k;
        }
    }
    return $keys;
}

/** Gives an account a free license right away (no key typing needed). */
function ra_give_license(array $user, string $note): string
{
    $key = ra_create_keys(1, $note === '' ? 'Given from admin' : $note)[0];
    db()->prepare('UPDATE mh_licenses SET uid = ?, email = ?, activated = ? WHERE license_key = ?')
        ->execute([$user['uid'], $user['email'], now_ms(), $key]);
    ra_put_doc($user['uid'], 'root', 'license', [
        'key' => $key,
        'source' => 'admin',
        'product' => 'Masher Hisab',
        'activatedAt' => now_ms(),
        'device' => '',
    ]);
    return $key;
}

function ra_block_key(string $key, string $reason): int
{
    db()->prepare('INSERT INTO mh_key_blocks (license_key, reason, created) VALUES (?, ?, ?)
        ON DUPLICATE KEY UPDATE reason = VALUES(reason)')->execute([$key, substr($reason, 0, 250), now_ms()]);
    db()->prepare('UPDATE mh_licenses SET blocked = 1 WHERE license_key = ?')->execute([$key]);
    return ra_revoke_key($key);
}

function ra_unblock_key(string $key): void
{
    db()->prepare('DELETE FROM mh_key_blocks WHERE license_key = ?')->execute([$key]);
    db()->prepare('UPDATE mh_licenses SET blocked = 0 WHERE license_key = ?')->execute([$key]);
}

/**
 * Gives more trial days: the trial then ends $days after today or after its
 * current end, whichever is later. A minus number takes days off the end.
 */
function ra_trial_shift(string $uid, int $days): void
{
    $len = RA_TRIAL_DAYS * 86400000;
    $t = ra_doc($uid, 'root', 'trial');
    $start = isset($t['start']) && is_numeric($t['start']) ? (int) $t['start'] : now_ms();
    $end = $start + $len;
    $newEnd = $days >= 0 ? max($end, now_ms()) + $days * 86400000 : $end + $days * 86400000;
    $newEnd = min($newEnd, now_ms() + 366 * 86400000);
    ra_put_doc($uid, 'root', 'trial', ['start' => $newEnd - $len]);
}

function ra_trial_set(string $uid, int $start): void
{
    ra_put_doc($uid, 'root', 'trial', ['start' => $start]);
}

function ra_user_backup_dir(string $uid): string
{
    return RA_API . '/userbackups/' . hash('sha256', $uid);
}

/** The user's own app backups kept on the server, newest first. */
function ra_user_backups(string $uid): array
{
    $dir = ra_user_backup_dir($uid);
    $out = [];
    foreach (glob("$dir/*.mhbackup") ?: [] as $f) {
        $id = basename($f, '.mhbackup');
        $dev = @file_get_contents(preg_replace('/\.mhbackup$/', '.device', $f));
        $out[] = ['id' => $id, 'size' => (int) filesize($f), 'time' => (int) explode('_', $id)[0], 'device' => $dev === false ? '' : $dev];
    }
    usort($out, fn ($a, $b) => $b['time'] <=> $a['time']);
    return $out;
}

/** Every user with license / trial state and phone count (small tables, so PHP filters). */
function ra_all_users(): array
{
    $pdo = db();
    $docs = [];
    foreach ($pdo->query("SELECT uid, id, data FROM mh_docs WHERE col = 'root' AND id IN ('license', 'trial') AND deleted = 0") as $r) {
        $docs[$r['uid']][$r['id']] = ra_json($r['data']);
    }
    $devices = [];
    foreach ($pdo->query('SELECT uid, COUNT(*) n, MAX(last_seen) seen,
            SUBSTRING_INDEX(GROUP_CONCAT(platform ORDER BY last_seen DESC), \',\', 1) plat,
            SUBSTRING_INDEX(GROUP_CONCAT(app_version ORDER BY last_seen DESC), \',\', 1) ver
            FROM mh_clients GROUP BY uid') as $r) {
        $devices[$r['uid']] = $r;
    }
    $out = [];
    foreach ($pdo->query('SELECT uid, email, name, created, last_seen FROM mh_users') as $u) {
        $d = $docs[$u['uid']] ?? [];
        $u['license'] = $d['license'] ?? null;
        $u['trial'] = $d['trial'] ?? null;
        $u['st'] = ra_state($u['license'], $u['trial']);
        $u['devices'] = (int) ($devices[$u['uid']]['n'] ?? 0);
        $u['platform'] = (string) ($devices[$u['uid']]['plat'] ?? '');
        $u['version'] = (string) ($devices[$u['uid']]['ver'] ?? '');
        $out[] = $u;
    }
    return $out;
}

/** Every key the panel knows about, grouped. */
function ra_all_keys(): array
{
    $pdo = db();
    $emails = [];
    foreach ($pdo->query('SELECT uid, email, name FROM mh_users') as $u) {
        $emails[$u['uid']] = $u['email'] !== '' ? $u['email'] : ($u['name'] !== '' ? $u['name'] : $u['uid']);
    }
    $keys = [];
    $add = function (string $key, string $source) use (&$keys) {
        if (!isset($keys[$key])) {
            $keys[$key] = ['key' => $key, 'source' => $source, 'users' => [], 'admin' => null, 'blocked' => false, 'reason' => '', 'activated' => 0];
        }
    };
    foreach ($pdo->query("SELECT uid, data FROM mh_docs WHERE col = 'root' AND id = 'license' AND deleted = 0") as $r) {
        $d = ra_json($r['data']);
        $k = ra_key((string) ($d['key'] ?? ''));
        if ($k === '') {
            continue;
        }
        $add($k, (string) ($d['source'] ?? 'shop'));
        $at = (int) ($d['activatedAt'] ?? 0);
        $keys[$k]['users'][] = ['uid' => $r['uid'], 'email' => $emails[$r['uid']] ?? $r['uid'], 'at' => $at, 'device' => (string) ($d['device'] ?? ''), 'product' => (string) ($d['product'] ?? '')];
        $keys[$k]['activated'] = max($keys[$k]['activated'], $at);
    }
    foreach ($pdo->query('SELECT * FROM mh_licenses') as $r) {
        $k = ra_key((string) $r['license_key']);
        $add($k, 'admin');
        $keys[$k]['source'] = 'admin';
        $keys[$k]['admin'] = $r;
        if ((int) $r['blocked'] === 1) {
            $keys[$k]['blocked'] = true;
        }
        if (!$keys[$k]['activated']) {
            $keys[$k]['activated'] = (int) ($r['activated'] ?: $r['created']);
        }
    }
    foreach ($pdo->query('SELECT * FROM mh_key_blocks') as $r) {
        $k = ra_key((string) $r['license_key']);
        $add($k, 'blocked');
        $keys[$k]['blocked'] = true;
        $keys[$k]['reason'] = (string) $r['reason'];
        if (!$keys[$k]['activated']) {
            $keys[$k]['activated'] = (int) $r['created'];
        }
    }
    foreach ($keys as &$k) {
        if ($k['blocked']) {
            $k['status'] = 'blocked';
        } elseif ($k['users']) {
            $k['status'] = 'active';
        } elseif ($k['admin'] !== null && !empty($k['admin']['uid'])) {
            $k['status'] = 'removed';
        } else {
            $k['status'] = 'unused';
        }
        $k['owner'] = $k['admin'] !== null && !empty($k['admin']['uid']) ? ($emails[$k['admin']['uid']] ?? (string) $k['admin']['email']) : '';
    }
    unset($k);
    usort($keys, fn ($a, $b) => $b['activated'] <=> $a['activated']);
    return $keys;
}
