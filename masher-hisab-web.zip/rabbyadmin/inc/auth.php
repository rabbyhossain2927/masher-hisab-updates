<?php
// Masher Hisab admin panel: first-time setup, sign-in and the 2-step code.
declare(strict_types=1);

function ra_auth_top(string $title, string $sub = ''): void
{
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . ra_h($title) . ' · Masher Hisab Admin</title><link rel="stylesheet" href="assets/admin.css?v=' . RA_VERSION . '">'
        . '<meta name="robots" content="noindex, nofollow"></head><body><div class="center"><div class="auth">'
        . '<div class="row" style="gap:10px;margin-bottom:16px"><span class="brand" style="padding:0;color:var(--text)"><span class="dot">M</span></span>'
        . '<div><div style="font-weight:700">Masher Hisab</div><div class="muted small">Admin panel</div></div></div>'
        . '<div class="card stack"><div><h1>' . ra_h($title) . '</h1>' . ($sub !== '' ? '<p class="muted" style="margin:4px 0 0">' . $sub . '</p>' : '') . '</div>';
    foreach (ra_take_flash() as [$k, $m]) {
        echo '<div class="flash ' . ra_h($k) . '" style="margin:0">' . ra_h($m) . '</div>';
    }
}

function ra_auth_bottom(bool $qr = false): void
{
    echo '</div></div></div>';
    if ($qr) {
        echo '<script src="assets/qrcode.js?v=' . RA_VERSION . '"></script>';
    }
    echo '<script src="assets/admin.js?v=' . RA_VERSION . '"></script></body></html>';
}

/** First run: no admin yet. Needs the admin_password from masher-api/config.php. */
function ra_setup(): void
{
    $setupPass = (string) cfg('admin_password');
    $weak = $setupPass === '' || str_starts_with($setupPass, 'CHANGE-ME') || strlen($setupPass) < 8;

    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ra_csrf_ok()) {
        if (ra_too_many_fails()) {
            ra_flash('Too many wrong tries. Wait 15 minutes.', 'bad');
        } elseif (($_POST['step'] ?? '') === '1' && !$weak) {
            $user = strtolower(trim((string) ($_POST['username'] ?? '')));
            $pass = (string) ($_POST['password'] ?? '');
            if (!hash_equals($setupPass, (string) ($_POST['setup'] ?? ''))) {
                ra_add_fail();
                ra_flash('The setup password is wrong.', 'bad');
            } elseif (!preg_match('/^[a-z0-9._-]{3,32}$/', $user)) {
                ra_flash('Username: 3–32 letters, numbers, dot, dash or underscore.', 'bad');
            } elseif (strlen($pass) < 10) {
                ra_flash('Choose a password with at least 10 characters.', 'bad');
            } elseif ($pass !== (string) ($_POST['password2'] ?? '')) {
                ra_flash('The two passwords are not the same.', 'bad');
            } else {
                $_SESSION['setup'] = ['user' => $user, 'hash' => password_hash($pass, PASSWORD_DEFAULT), 'secret' => ra_totp_new_secret()];
            }
        } elseif (($_POST['step'] ?? '') === '2' && !empty($_SESSION['setup'])) {
            $s = $_SESSION['setup'];
            $step = ra_totp_check($s['secret'], (string) ($_POST['code'] ?? ''));
            if ($step === 0) {
                ra_add_fail();
                ra_flash('That code is not right. Check the time on your phone and try the newest code.', 'bad');
            } else {
                [$plain, $json] = ra_new_recovery();
                $pdo = db();
                $pdo->prepare('INSERT INTO mh_admins (username, pass_hash, totp_secret, totp_last, recovery, created, last_login, last_ip) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
                    ->execute([$s['user'], $s['hash'], $s['secret'], $step, $json, now_ms(), now_ms(), ra_ip()]);
                $id = (int) $pdo->lastInsertId();
                unset($_SESSION['setup']);
                ra_clear_fails();
                session_regenerate_id(true);
                $_SESSION['admin_id'] = $id;
                $_SESSION['admin_name'] = $s['user'];
                $_SESSION['totp_ok'] = true;
                $_SESSION['seen'] = time();
                $_SESSION['recovery_show'] = $plain;
                ra_log('setup', $s['user'], 'Admin account created');
                ra_redirect(ra_url('recovery'));
            }
        }
        ra_redirect('./');
    }

    if ($weak) {
        ra_auth_top('Set up the admin panel');
        echo '<div class="note">First set a setup password on the server:<br>open <b>masher-api/config.php</b> in cPanel → File Manager and change <code>admin_password</code> to a long password (at least 8 characters). Then reload this page.</div>';
        ra_auth_bottom();
        return;
    }

    if (!empty($_SESSION['setup'])) {
        $s = $_SESSION['setup'];
        ra_auth_top('Turn on 2-step sign-in', 'Scan this with Google Authenticator (or any authenticator app), then type the 6-digit code it shows.');
        echo '<div class="qr"><div id="qr" data-uri="' . ra_h(ra_totp_uri($s['secret'], $s['user'])) . '"></div></div>'
            . '<div class="small muted">Can\'t scan? Enter this key by hand:<br><code style="word-break:break-all">' . ra_h(trim(chunk_split($s['secret'], 4, ' '))) . '</code></div>'
            . '<form method="post" class="stack">' . ra_csrf() . '<input type="hidden" name="step" value="2">'
            . '<div class="field"><label for="code">6-digit code</label><input id="code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="6" required autofocus></div>'
            . '<button class="btn btn-main" type="submit">Finish setup</button></form>';
        ra_auth_bottom(true);
        return;
    }

    ra_auth_top('Set up the admin panel', 'Create your admin account. You need the <b>admin_password</b> from masher-api/config.php once.');
    echo '<form method="post" class="stack">' . ra_csrf() . '<input type="hidden" name="step" value="1">'
        . '<div class="field"><label for="setup">Setup password (from config.php)</label><input id="setup" name="setup" type="password" required autocomplete="off"></div>'
        . '<div class="field"><label for="username">Your admin username</label><input id="username" name="username" type="text" required autocomplete="username" value="rabby"></div>'
        . '<div class="field"><label for="password">New password</label><input id="password" name="password" type="password" required minlength="10" autocomplete="new-password"></div>'
        . '<div class="field"><label for="password2">New password again</label><input id="password2" name="password2" type="password" required minlength="10" autocomplete="new-password"></div>'
        . '<button class="btn btn-main" type="submit">Next: 2-step sign-in</button></form>';
    ra_auth_bottom();
}

/** Signs the admin in and opens the panel. */
function ra_finish_login(array $a, string $how): void
{
    ra_clear_fails();
    session_regenerate_id(true);
    unset($_SESSION['pending_id'], $_SESSION['pending_at']);
    $_SESSION['admin_id'] = (int) $a['id'];
    $_SESSION['admin_name'] = (string) $a['username'];
    $_SESSION['totp_ok'] = true;
    $_SESSION['seen'] = time();
    db()->prepare('UPDATE mh_admins SET last_login = ?, last_ip = ? WHERE id = ?')->execute([now_ms(), ra_ip(), $a['id']]);
    ra_log('login', $a['username'], $how);
    ra_redirect('./');
}

function ra_login(): void
{
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && ra_csrf_ok()) {
        if (ra_too_many_fails()) {
            ra_flash('Too many wrong tries. Wait 15 minutes and try again.', 'bad');
            ra_redirect('./');
        }
        $pdo = db();
        if (($_POST['step'] ?? '') === 'password') {
            $st = $pdo->prepare('SELECT * FROM mh_admins WHERE username = ?');
            $st->execute([strtolower(trim((string) ($_POST['username'] ?? '')))]);
            $a = $st->fetch();
            $pass = (string) ($_POST['password'] ?? '');
            if ($a && password_verify($pass, $a['pass_hash'])) {
                if (password_needs_rehash($a['pass_hash'], PASSWORD_DEFAULT)) {
                    $pdo->prepare('UPDATE mh_admins SET pass_hash = ? WHERE id = ?')->execute([password_hash($pass, PASSWORD_DEFAULT), $a['id']]);
                }
                if (ra_trust_check((int) $a['id'])) {
                    ra_finish_login($a, 'remembered device');
                }
                session_regenerate_id(true);
                $_SESSION['pending_id'] = (int) $a['id'];
                $_SESSION['pending_at'] = time();
            } else {
                ra_add_fail();
                ra_flash('Wrong username or password.', 'bad');
            }
        } elseif (($_POST['step'] ?? '') === 'code' && !empty($_SESSION['pending_id']) && time() - (int) $_SESSION['pending_at'] < 300) {
            $st = $pdo->prepare('SELECT * FROM mh_admins WHERE id = ?');
            $st->execute([(int) $_SESSION['pending_id']]);
            $a = $st->fetch();
            $code = trim((string) ($_POST['code'] ?? ''));
            $ok = false;
            if ($a) {
                $step = ra_totp_check($a['totp_secret'], $code, (int) $a['totp_last']);
                if ($step > 0) {
                    $pdo->prepare('UPDATE mh_admins SET totp_last = ? WHERE id = ?')->execute([$step, $a['id']]);
                    $ok = true;
                } elseif (strlen($code) > 6 && ($left = ra_use_recovery((string) $a['recovery'], $code)) !== null) {
                    $pdo->prepare('UPDATE mh_admins SET recovery = ? WHERE id = ?')->execute([$left, $a['id']]);
                    $ok = true;
                    ra_flash('You used a recovery code. ' . count(json_decode($left, true) ?: []) . ' left — make new ones in Settings.', 'warn');
                }
            }
            if ($ok) {
                if (!empty($_POST['trust'])) {
                    ra_trust_add((int) $a['id']);
                }
                ra_finish_login($a, !empty($_POST['trust']) ? 'code · device remembered' : 'code');
            }
            ra_add_fail();
            ra_flash('That code is not right.', 'bad');
        } else {
            unset($_SESSION['pending_id'], $_SESSION['pending_at']);
            ra_flash('Sign-in timed out. Start again.', 'warn');
        }
        ra_redirect('./');
    }

    if (!empty($_SESSION['pending_id']) && time() - (int) ($_SESSION['pending_at'] ?? 0) < 300) {
        ra_auth_top('2-step code', 'Open your authenticator app and type the 6-digit code for Masher Hisab Admin. Lost your phone? Use a recovery code.');
        echo '<form method="post" class="stack">' . ra_csrf() . '<input type="hidden" name="step" value="code">'
            . '<div class="field"><label for="code">Code</label><input id="code" name="code" type="text" inputmode="numeric" autocomplete="one-time-code" maxlength="11" required autofocus></div>'
            . '<label class="row" style="font-weight:500;gap:8px"><input type="checkbox" name="trust" value="1" checked> Remember this device for ' . RA_TRUST_DAYS . ' days — no code needed here</label>'
            . '<button class="btn btn-main" type="submit">Sign in</button></form>'
            . '<a class="small" href="?p=logout">Start again</a>';
        ra_auth_bottom();
        return;
    }

    ra_auth_top('Sign in');
    echo '<form method="post" class="stack">' . ra_csrf() . '<input type="hidden" name="step" value="password">'
        . '<div class="field"><label for="username">Username</label><input id="username" name="username" type="text" required autocomplete="username" autofocus></div>'
        . '<div class="field"><label for="password">Password</label><input id="password" name="password" type="password" required autocomplete="current-password"></div>'
        . '<button class="btn btn-main" type="submit">Continue</button></form>';
    ra_auth_bottom();
}

/** Shown once after setup or after making new codes. */
function ra_recovery_page(): void
{
    $codes = $_SESSION['recovery_show'] ?? null;
    if (!$codes) {
        ra_redirect('./');
    }
    unset($_SESSION['recovery_show']);
    ra_auth_top('Save your recovery codes', 'If you lose your phone, each code signs you in once instead of the 6-digit code. Save them somewhere safe now — they will not be shown again.');
    echo '<div class="codes">';
    foreach ($codes as $c) {
        echo '<code>' . ra_h($c) . '</code>';
    }
    echo '</div><button class="btn" type="button" data-copy="' . ra_h(implode("\n", $codes)) . '">Copy all</button>'
        . '<a class="btn btn-main" href="./">I saved them — open the panel</a>';
    ra_auth_bottom();
}
