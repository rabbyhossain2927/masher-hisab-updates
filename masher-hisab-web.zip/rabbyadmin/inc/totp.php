<?php
// Two-step sign-in codes (Google Authenticator, Authy, Microsoft Authenticator…).
declare(strict_types=1);

const RA_B32 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function ra_b32_encode(string $bin): string
{
    $bits = '';
    foreach (str_split($bin) as $c) {
        $bits .= str_pad(decbin(ord($c)), 8, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 5) as $chunk) {
        $out .= RA_B32[bindec(str_pad($chunk, 5, '0'))];
    }
    return $out;
}

function ra_b32_decode(string $b32): string
{
    $b32 = strtoupper(preg_replace('/[^A-Za-z2-7]/', '', $b32) ?? '');
    $bits = '';
    foreach (str_split($b32) as $c) {
        $bits .= str_pad(decbin((int) strpos(RA_B32, $c)), 5, '0', STR_PAD_LEFT);
    }
    $out = '';
    foreach (str_split($bits, 8) as $byte) {
        if (strlen($byte) === 8) {
            $out .= chr(bindec($byte));
        }
    }
    return $out;
}

function ra_totp_new_secret(): string
{
    return ra_b32_encode(random_bytes(20));
}

function ra_totp_at(string $secret, int $step): string
{
    $key = ra_b32_decode($secret);
    $msg = pack('N2', 0, $step);
    $hash = hash_hmac('sha1', $msg, $key, true);
    $o = ord($hash[19]) & 0x0f;
    $num = ((ord($hash[$o]) & 0x7f) << 24) | (ord($hash[$o + 1]) << 16) | (ord($hash[$o + 2]) << 8) | ord($hash[$o + 3]);
    return str_pad((string) ($num % 1000000), 6, '0', STR_PAD_LEFT);
}

/**
 * Checks a 6-digit code (one step either side for clock drift).
 * Returns the matching step, or 0. A step at or below $lastStep was
 * already used and is refused.
 */
function ra_totp_check(string $secret, string $code, int $lastStep = 0): int
{
    $code = preg_replace('/\D/', '', $code) ?? '';
    if (strlen($code) !== 6) {
        return 0;
    }
    $now = intdiv(time(), 30);
    for ($s = $now - 1; $s <= $now + 1; $s++) {
        if ($s > $lastStep && hash_equals(ra_totp_at($secret, $s), $code)) {
            return $s;
        }
    }
    return 0;
}

function ra_totp_uri(string $secret, string $user): string
{
    $label = rawurlencode('Masher Hisab Admin:' . $user);
    return "otpauth://totp/$label?secret=$secret&issuer=" . rawurlencode('Masher Hisab Admin') . '&digits=6&period=30';
}

/** 8 one-time recovery codes: [plain list, json of hashes]. */
function ra_new_recovery(): array
{
    $plain = [];
    $hashes = [];
    for ($i = 0; $i < 8; $i++) {
        $c = strtoupper(bin2hex(random_bytes(5)));
        $c = substr($c, 0, 5) . '-' . substr($c, 5, 5);
        $plain[] = $c;
        $hashes[] = password_hash($c, PASSWORD_DEFAULT);
    }
    return [$plain, json_encode($hashes)];
}

/** Uses a recovery code. Returns the new json (code removed) or null. */
function ra_use_recovery(string $json, string $code): ?string
{
    $code = strtoupper(trim($code));
    $list = json_decode($json, true);
    if (!is_array($list)) {
        return null;
    }
    foreach ($list as $i => $hash) {
        if (is_string($hash) && password_verify($code, $hash)) {
            unset($list[$i]);
            return json_encode(array_values($list));
        }
    }
    return null;
}
