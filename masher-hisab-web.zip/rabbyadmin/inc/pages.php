<?php
// Masher Hisab admin panel: the pages.
declare(strict_types=1);

function ra_page_dashboard(): void
{
    $pdo = db();
    $now = now_ms();
    $day = 86400000;
    $users = ra_all_users();
    $total = count($users);
    $active = ['1' => 0, '7' => 0, '30' => 0];
    $new7 = 0;
    $new30 = 0;
    $states = ['licensed' => 0, 'trial' => 0, 'expired' => 0, 'new' => 0];
    foreach ($users as $u) {
        foreach ([1, 7, 30] as $d) {
            if ((int) $u['last_seen'] >= $now - $d * $day) {
                $active[(string) $d]++;
            }
        }
        if ((int) $u['created'] >= $now - 7 * $day) {
            $new7++;
        }
        if ((int) $u['created'] >= $now - 30 * $day) {
            $new30++;
        }
        $states[$u['st']['state']]++;
    }

    // New users and active users per day, last 30 days (Bangladesh time).
    $labels = [];
    $newPer = [];
    $dauPer = [];
    $index = [];
    for ($i = 29; $i >= 0; $i--) {
        $d = date('Y-m-d', time() - $i * 86400);
        $index[$d] = 29 - $i;
        $labels[] = date('j M', time() - $i * 86400);
        $newPer[] = 0;
        $dauPer[] = 0;
    }
    foreach ($users as $u) {
        $d = date('Y-m-d', intdiv((int) $u['created'], 1000));
        if (isset($index[$d])) {
            $newPer[$index[$d]]++;
        }
    }
    $st = $pdo->prepare('SELECT day, COUNT(*) n FROM mh_active_days WHERE day >= ? GROUP BY day');
    $st->execute([date('Y-m-d', time() - 29 * 86400)]);
    foreach ($st->fetchAll() as $r) {
        if (isset($index[$r['day']])) {
            $dauPer[$index[$r['day']]] = (int) $r['n'];
        }
    }

    $plat = [];
    $vers = [];
    $st = $pdo->prepare('SELECT platform, app_version FROM mh_clients WHERE last_seen >= ?');
    $st->execute([$now - 30 * $day]);
    foreach ($st->fetchAll() as $r) {
        $p = $r['platform'] === 'web' ? 'Web app' : ($r['platform'] === 'android' ? 'Android' : ucfirst((string) $r['platform']));
        $plat[$p] = ($plat[$p] ?? 0) + 1;
        $v = $r['app_version'] !== '' ? $r['app_version'] : 'Older than MH 13.6.3';
        $vers[$v] = ($vers[$v] ?? 0) + 1;
    }
    arsort($plat);
    arsort($vers);
    $vers = array_slice($vers, 0, 6, true);

    $src = [];
    foreach ($users as $u) {
        if ($u['license'] !== null) {
            $s = ra_source_label((string) ($u['license']['source'] ?? 'shop'));
            $src[$s] = ($src[$s] ?? 0) + 1;
        }
    }
    arsort($src);

    $txns = (int) $pdo->query("SELECT COUNT(*) FROM mh_docs WHERE col = 'txns' AND deleted = 0")->fetchColumn();
    $devices = (int) $pdo->query('SELECT COUNT(*) FROM mh_clients')->fetchColumn();
    $dbSize = (int) $pdo->query("SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name LIKE 'mh\\\\_%'")->fetchColumn();
    $backups = ra_backup_list();
    $lastBackup = $backups[0]['time'] ?? 0;

    usort($users, fn ($a, $b) => (int) $b['created'] <=> (int) $a['created']);
    $recent = array_slice($users, 0, 6);
    $log = $pdo->query('SELECT * FROM mh_admin_log ORDER BY id DESC LIMIT 6')->fetchAll();

    $actions = '<a class="btn" href="' . ra_url('users') . '">All users</a>';
    ra_top('Dashboard', 'dashboard', 'How Masher Hisab is being used, ' . date('l, j F Y'), $actions);

    if (ra_server_needs_update()) {
        echo '<div class="flash warn">The server API files are older than this panel. ' . ra_post_btn('server_update', 'Update server now', ['back' => ra_url('dashboard')], 'btn btn-sm btn-dark') . '</div>';
    }

    echo '<div class="grid g4">';
    $cards = [
        ['Total users', ra_num($total), "+$new7 this week · +$new30 this month"],
        ['Active today', ra_num($active['1']), 'Opened and synced in the last 24 hours'],
        ['Active this week', ra_num($active['7']), ra_num($active['30']) . ' this month'],
        ['Licensed', ra_num($states['licensed']), $total ? round($states['licensed'] / $total * 100) . '% of users' : '—'],
        ['On trial', ra_num($states['trial']), 'Trial still running'],
        ['Trial ended', ra_num($states['expired']), 'No license yet — can buy'],
        ['Phones & browsers', ra_num($devices), 'Seen since tracking started'],
        ['Transactions stored', ra_num($txns), 'Database ' . ra_size($dbSize)],
    ];
    foreach ($cards as [$k, $v, $s]) {
        echo '<div class="card stat"><div class="k">' . ra_h($k) . '</div><div class="v">' . $v . '</div><div class="s">' . ra_h($s) . '</div></div>';
    }
    echo '</div>';

    echo '<div class="grid g2" style="margin-top:14px">'
        . '<div class="card"><div class="card-head"><h2>Active users per day</h2><span class="muted small">last 30 days</span></div>' . ra_bars($labels, $dauPer, '#1DBF73') . '</div>'
        . '<div class="card"><div class="card-head"><h2>New users per day</h2><span class="muted small">last 30 days</span></div>' . ra_bars($labels, $newPer, '#3D8BFF') . '</div>'
        . '</div>';

    echo '<div class="grid g3" style="margin-top:14px">'
        . '<div class="card"><h2>Android vs web</h2>' . ra_split($plat, ['#1DBF73', '#3D8BFF', '#F5A524']) . '<p class="muted small" style="margin:10px 0 0">Phones and browsers active in the last 30 days.</p></div>'
        . '<div class="card"><h2>App versions</h2>' . ra_split($vers) . '</div>'
        . '<div class="card"><h2>Licenses by source</h2>' . ra_split($src, ['#3D8BFF', '#F5A524', '#1DBF73']) . '</div>'
        . '</div>';

    echo '<div class="grid g2" style="margin-top:14px"><div class="card"><div class="card-head"><h2>Newest users</h2><a class="small" href="' . ra_url('users', ['sort' => 'new']) . '">See all</a></div>';
    if (!$recent) {
        echo '<div class="empty">No users yet.</div>';
    }
    foreach ($recent as $u) {
        echo '<div class="row between" style="padding:8px 0;border-top:1px solid var(--line2)"><div><a href="' . ra_url('user', ['uid' => $u['uid']]) . '">' . ra_h($u['email'] ?: $u['uid']) . '</a>'
            . '<div class="muted small">Joined ' . ra_ago($u['created']) . '</div></div>' . ra_pill($u['st']['state'], $u['st']['label']) . '</div>';
    }
    echo '</div><div class="card"><div class="card-head"><h2>Recent admin actions</h2><a class="small" href="' . ra_url('log') . '">Activity log</a></div>';
    if (!$log) {
        echo '<div class="empty">Nothing yet.</div>';
    }
    foreach ($log as $l) {
        echo '<div style="padding:8px 0;border-top:1px solid var(--line2)"><b>' . ra_h(str_replace('_', ' ', $l['action'])) . '</b> <span class="muted">' . ra_h($l['target']) . '</span>'
            . '<div class="muted small">' . ra_h($l['admin']) . ' · ' . ra_ago($l['at']) . '</div></div>';
    }
    echo '</div></div>';

    echo '<div class="card" style="margin-top:14px"><div class="row between"><div><h2>Last database backup</h2><div class="muted">'
        . ($lastBackup ? ra_ago($lastBackup * 1000) . ' · ' . ra_when($lastBackup * 1000) : 'No backup yet') . ' · Daily automatic backup is <b>' . (ra_autobackup_on() ? 'on' : 'off') . '</b></div></div>'
        . ra_post_btn('backup_make', 'Back up now', ['back' => ra_url('dashboard')], 'btn btn-main') . '</div></div>';
    ra_bottom();
}

function ra_page_users(): void
{
    $q = trim((string) ($_GET['q'] ?? ''));
    $status = (string) ($_GET['status'] ?? '');
    $plat = (string) ($_GET['plat'] ?? '');
    $sort = (string) ($_GET['sort'] ?? 'seen');
    $users = ra_all_users();
    $users = array_values(array_filter($users, function ($u) use ($q, $status, $plat) {
        if ($q !== '' && stripos($u['email'] . ' ' . $u['name'] . ' ' . $u['uid'], $q) === false) {
            return false;
        }
        if ($status !== '' && $u['st']['state'] !== $status) {
            return false;
        }
        if ($plat !== '' && $u['platform'] !== $plat) {
            return false;
        }
        return true;
    }));
    usort($users, function ($a, $b) use ($sort) {
        switch ($sort) {
            case 'new':
                return (int) $b['created'] <=> (int) $a['created'];
            case 'old':
                return (int) $a['created'] <=> (int) $b['created'];
            case 'email':
                return strcasecmp((string) $a['email'], (string) $b['email']);
            default:
                return (int) $b['last_seen'] <=> (int) $a['last_seen'];
        }
    });

    $per = 50;
    $pages = max(1, (int) ceil(count($users) / $per));
    $page = max(1, min($pages, (int) ($_GET['page'] ?? 1)));
    $rows = array_slice($users, ($page - 1) * $per, $per);
    $qs = ['p' => 'users', 'q' => $q, 'status' => $status, 'plat' => $plat, 'sort' => $sort];

    ra_top('Users', 'users', ra_num(count($users)) . ' user' . (count($users) === 1 ? '' : 's') . ($q !== '' || $status !== '' || $plat !== '' ? ' match' : ' in total'));

    echo '<form method="get" class="row" style="margin-bottom:14px"><input type="hidden" name="p" value="users">'
        . '<input type="search" name="q" value="' . ra_h($q) . '" placeholder="Search email or name" aria-label="Search users" style="flex:1 1 240px">'
        . '<select name="status" data-auto aria-label="Status"><option value="">All statuses</option>';
    foreach (['licensed' => 'Licensed', 'trial' => 'On trial', 'expired' => 'Trial ended', 'new' => 'No trial yet'] as $k => $v) {
        echo '<option value="' . $k . '"' . ($status === $k ? ' selected' : '') . '>' . $v . '</option>';
    }
    echo '</select><select name="plat" data-auto aria-label="Platform"><option value="">Android and web</option>'
        . '<option value="android"' . ($plat === 'android' ? ' selected' : '') . '>Android</option><option value="web"' . ($plat === 'web' ? ' selected' : '') . '>Web app</option></select>'
        . '<select name="sort" data-auto aria-label="Sort">';
    foreach (['seen' => 'Last seen', 'new' => 'Newest first', 'old' => 'Oldest first', 'email' => 'Email A–Z'] as $k => $v) {
        echo '<option value="' . $k . '"' . ($sort === $k ? ' selected' : '') . '>' . $v . '</option>';
    }
    echo '</select><button class="btn btn-dark" type="submit">Search</button></form>';

    echo '<div class="tbl-wrap"><table><thead><tr><th>User</th><th>Status</th><th>Joined</th><th>Last seen</th><th>Phones</th><th>App</th></tr></thead><tbody>';
    if (!$rows) {
        echo '<tr><td colspan="6" class="empty">No users found.</td></tr>';
    }
    foreach ($rows as $u) {
        echo '<tr><td><a href="' . ra_url('user', ['uid' => $u['uid']]) . '"><b>' . ra_h($u['email'] ?: '(no email)') . '</b></a><div class="muted small">' . ra_h($u['name']) . '</div></td>'
            . '<td>' . ra_pill($u['st']['state'], $u['st']['label']) . '</td>'
            . '<td>' . ra_date($u['created']) . '</td><td title="' . ra_h(ra_when($u['last_seen'])) . '">' . ra_ago($u['last_seen']) . '</td>'
            . '<td>' . ($u['devices'] ?: '—') . ($u['platform'] !== '' ? ' ' . ra_pill($u['platform'], $u['platform'] === 'web' ? 'Web' : 'Android') : '') . '</td>'
            . '<td class="small">' . ra_h($u['version'] ?: '—') . '</td></tr>';
    }
    echo '</tbody></table></div>' . ra_pager($page, $pages, $qs);
    ra_bottom();
}

function ra_page_user(): void
{
    $uid = (string) ($_GET['uid'] ?? '');
    $u = ra_user($uid);
    if (!$u) {
        ra_flash('That user was not found.', 'bad');
        ra_redirect(ra_url('users'));
    }
    $pdo = db();
    $lic = ra_doc($uid, 'root', 'license');
    $trial = ra_doc($uid, 'root', 'trial');
    $profile = ra_doc($uid, 'root', 'profile');
    $st = ra_state($lic, $trial);
    $counts = [];
    $q = $pdo->prepare('SELECT col, COUNT(*) n FROM mh_docs WHERE uid = ? AND deleted = 0 GROUP BY col');
    $q->execute([$uid]);
    foreach ($q->fetchAll() as $r) {
        $counts[$r['col']] = (int) $r['n'];
    }
    $q = $pdo->prepare('SELECT * FROM mh_clients WHERE uid = ? ORDER BY last_seen DESC');
    $q->execute([$uid]);
    $devices = $q->fetchAll();
    $q = $pdo->prepare('SELECT COUNT(*) FROM mh_active_days WHERE uid = ? AND day >= ?');
    $q->execute([$uid, date('Y-m-d', time() - 29 * 86400)]);
    $days30 = (int) $q->fetchColumn();
    $backups = ra_user_backups($uid);
    $back = ra_url('user', ['uid' => $uid]);
    $who = $u['email'] ?: $uid;
    $base = ['uid' => $uid, 'back' => $back];

    ra_top($who, 'users', ra_h($u['name']) . ($u['name'] !== '' ? ' · ' : '') . 'Joined ' . ra_when($u['created']), '<a class="btn" href="' . ra_url('users') . '">All users</a>');

    echo '<div class="grid g4">'
        . '<div class="card stat"><div class="k">Status</div><div class="v" style="font-size:18px;margin-top:6px">' . ra_pill($st['state'], $st['label']) . '</div><div class="s">' . ($st['end'] ? 'Trial ends ' . ra_when($st['end']) : '&nbsp;') . '</div></div>'
        . '<div class="card stat"><div class="k">Last seen</div><div class="v" style="font-size:20px">' . ra_ago($u['last_seen']) . '</div><div class="s">' . ra_when($u['last_seen']) . '</div></div>'
        . '<div class="card stat"><div class="k">Days active (30 days)</div><div class="v">' . $days30 . '</div><div class="s">Days the app synced</div></div>'
        . '<div class="card stat"><div class="k">Transactions</div><div class="v">' . ra_num($counts['txns'] ?? 0) . '</div><div class="s">' . ra_num(array_sum($counts)) . ' records in total</div></div>'
        . '</div>';

    echo '<div class="grid g2" style="margin-top:14px"><div class="stack">';

    // License
    echo '<div class="card"><h2>License</h2>';
    if ($lic !== null) {
        echo '<div class="kv"><div>Key</div><div><code>' . ra_h($lic['key'] ?? '') . '</code> <button class="btn btn-sm" type="button" data-copy="' . ra_h($lic['key'] ?? '') . '">Copy</button></div>'
            . '<div>From</div><div>' . ra_pill((string) ($lic['source'] ?? 'shop'), ra_source_label((string) ($lic['source'] ?? 'shop'))) . '</div>'
            . '<div>Product</div><div>' . ra_h($lic['product'] ?? '—') . '</div>'
            . '<div>Activated</div><div>' . ra_when($lic['activatedAt'] ?? 0) . '</div></div>'
            . '<div class="row" style="margin-top:14px">'
            . ra_post_btn('remove_license', 'Remove license', $base, 'btn btn-sm', 'Remove the license from ' . $who . '? Their phones go back to trial or locked.')
            . ra_post_btn('key_block', 'Block this key', ['key' => (string) ($lic['key'] ?? ''), 'back' => $back], 'btn btn-sm btn-bad', 'Block this key everywhere? It stops working on every account.')
            . '</div>';
    } else {
        echo '<p class="muted" style="margin:0 0 12px">No license on this account.</p>'
            . '<form method="post" class="row">' . ra_csrf() . '<input type="hidden" name="do" value="give_license"><input type="hidden" name="uid" value="' . ra_h($uid) . '"><input type="hidden" name="back" value="' . ra_h($back) . '">'
            . '<input type="text" name="note" placeholder="Note (e.g. gift, refund)" aria-label="Note" style="flex:1 1 200px"><button class="btn btn-main" type="submit">Give free license</button></form>'
            . '<p class="muted small" style="margin:8px 0 0">Unlocks every phone of this account on the next sync (MH 13.6.3 or newer).</p>';
    }
    echo '</div>';

    // Trial
    echo '<div class="card"><h2>Trial</h2><div class="kv"><div>Started</div><div>' . ra_when($trial['start'] ?? 0) . '</div><div>Ends</div><div>' . ($st['end'] ? ra_when($st['end']) : '—') . '</div></div>'
        . '<form method="post" class="row" style="margin-top:14px">' . ra_csrf() . '<input type="hidden" name="do" value="trial_extend"><input type="hidden" name="uid" value="' . ra_h($uid) . '"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<label for="days" class="muted">Give</label><input id="days" type="number" name="days" value="7" min="-365" max="365" style="width:90px"><span class="muted">more days</span><button class="btn btn-dark" type="submit">Add days</button></form>'
        . '<div class="row" style="margin-top:10px">' . ra_post_btn('trial_reset', 'Start a new 7-day trial', $base) . ra_post_btn('trial_end', 'End trial now', $base, 'btn btn-sm btn-bad', 'End the trial now? Without a license the app locks.') . '</div></div>';

    // Data
    echo '<div class="card"><h2>Data in the cloud</h2><div class="kv">';
    $names = ['txns' => 'Transactions', 'accounts' => 'Accounts', 'categories' => 'Categories', 'budgets' => 'Budgets', 'recurring' => 'Recurring', 'groups' => 'Groups', 'root' => 'Other (goals, loans, settings…)'];
    foreach ($names as $k => $label) {
        echo '<div>' . $label . '</div><div>' . ra_num($counts[$k] ?? 0) . '</div>';
    }
    echo '</div>';
    if ($profile !== null && !empty($profile['name'])) {
        echo '<p class="muted small" style="margin:10px 0 0">Profile name in the app: ' . ra_h($profile['name']) . '</p>';
    }
    echo '</div></div><div class="stack">';

    // Devices
    echo '<div class="card"><h2>Phones and browsers</h2>';
    if (!$devices) {
        echo '<p class="muted" style="margin:0">Not seen yet. Devices show here after their next sync with the updated server.</p>';
    }
    foreach ($devices as $d) {
        echo '<div class="row between" style="padding:9px 0;border-top:1px solid var(--line2)"><div><b>' . ra_h($d['device_name'] ?: 'Unknown device') . '</b> ' . ra_pill($d['platform'], $d['platform'] === 'web' ? 'Web' : 'Android')
            . '<div class="muted small">' . ra_h($d['app_version'] ?: 'older app') . ' · first ' . ra_date($d['first_seen']) . '</div></div><span class="muted small">' . ra_ago($d['last_seen']) . '</span></div>';
    }
    echo '</div>';

    // Backups (count only: the contents stay private to the user)
    echo '<div class="card"><h2>App backups on the server</h2><p class="muted" style="margin:0">'
        . ($backups ? count($backups) . ' backup' . (count($backups) === 1 ? '' : 's') . ' · newest ' . ra_when($backups[0]['time']) . ' · ' . ra_size(array_sum(array_column($backups, 'size'))) : 'This user has no cloud backups.')
        . '</p><p class="muted small" style="margin:8px 0 0">Backups are private: only the user can restore or delete them in the app.</p></div>';

    echo '<div class="card"><h2>Technical</h2><div class="kv"><div>User id</div><div class="mono" style="word-break:break-all">' . ra_h($uid) . '</div><div>Data resets</div><div>' . (int) $u['wipe_gen'] . '</div></div>'
        . '<p class="muted small" style="margin:10px 0 0">User data is private. The admin panel cannot download, view or delete it — only the user can, from the app.</p></div>';
    echo '</div></div>';
    ra_bottom();
}

function ra_page_licenses(): void
{
    $q = trim((string) ($_GET['q'] ?? ''));
    $source = (string) ($_GET['source'] ?? '');
    $status = (string) ($_GET['status'] ?? '');
    $all = ra_all_keys();
    $counts = ['active' => 0, 'blocked' => 0, 'unused' => 0, 'removed' => 0];
    foreach ($all as $k) {
        $counts[$k['status']]++;
    }
    $keys = array_values(array_filter($all, function ($k) use ($q, $source, $status) {
        if ($q !== '') {
            $hay = $k['key'] . ' ' . $k['owner'] . ' ' . ($k['admin']['note'] ?? '') . ' ' . implode(' ', array_column($k['users'], 'email'));
            if (stripos($hay, $q) === false) {
                return false;
            }
        }
        return ($source === '' || $k['source'] === $source) && ($status === '' || $k['status'] === $status);
    }));

    if (isset($_GET['export'])) {
        ra_log('licenses_export', count($keys) . ' keys');
        ra_csv('masher-hisab-licenses-' . date('Y-m-d') . '.csv', ['Key', 'Source', 'Status', 'Used by', 'Activated', 'Note', 'Block reason'],
            array_map(fn ($k) => [$k['key'], ra_source_label($k['source']), $k['status'], implode('; ', array_column($k['users'], 'email')) ?: $k['owner'], ra_when($k['activated']), (string) ($k['admin']['note'] ?? ''), $k['reason']], $keys));
    }

    $per = 50;
    $pages = max(1, (int) ceil(count($keys) / $per));
    $page = max(1, min($pages, (int) ($_GET['page'] ?? 1)));
    $rows = array_slice($keys, ($page - 1) * $per, $per);
    $qs = ['p' => 'licenses', 'q' => $q, 'source' => $source, 'status' => $status];
    $back = '?' . http_build_query($qs + ['page' => $page]);

    ra_top('Licenses', 'licenses', ra_num($counts['active']) . ' active · ' . ra_num($counts['unused']) . ' unused · ' . ra_num($counts['blocked']) . ' blocked',
        '<a class="btn" href="?' . ra_h(http_build_query(array_merge($qs, ['export' => 1]))) . '">Export CSV</a>');

    $new = $_SESSION['new_keys'] ?? null;
    unset($_SESSION['new_keys']);
    if ($new) {
        echo '<div class="card" style="margin-bottom:14px;border-color:#B6E8CC;background:#F4FBF7"><div class="row between"><h2>New keys</h2><button class="btn btn-sm" type="button" data-copy="' . ra_h(implode("\n", $new)) . '">Copy all</button></div><div class="keys">';
        foreach ($new as $k) {
            echo '<code>' . ra_h($k) . '</code>';
        }
        echo '</div><p class="muted small" style="margin:10px 0 0">Send a key to a customer. They enter it in the app under License (MH 13.6.3 or newer).</p></div>';
    }

    echo '<div class="grid g2" style="margin-bottom:14px"><div class="card"><h2>Make Masher Hisab keys</h2>'
        . '<form method="post" class="row">' . ra_csrf() . '<input type="hidden" name="do" value="key_create"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<label for="count" class="muted">How many</label><input id="count" type="number" name="count" value="1" min="1" max="100" style="width:80px">'
        . '<input type="text" name="note" placeholder="Note (buyer, order no.)" aria-label="Note" style="flex:1 1 180px"><button class="btn btn-main" type="submit">Create</button></form>'
        . '<p class="muted small" style="margin:8px 0 0">Each key unlocks one account. To give a license straight to a user, open the user.</p></div>'
        . '<div class="card"><h2>Block a key</h2><form method="post" class="row">' . ra_csrf() . '<input type="hidden" name="do" value="key_block"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<input type="text" name="key" placeholder="Any key (shop, SupportKori or MH-…)" aria-label="Key" required style="flex:1 1 200px"><input type="text" name="reason" placeholder="Reason" aria-label="Reason" style="flex:1 1 120px">'
        . '<button class="btn btn-bad" type="submit">Block</button></form><p class="muted small" style="margin:8px 0 0">A blocked key is removed from every account and cannot be activated again.</p></div></div>';

    echo '<form method="get" class="row" style="margin-bottom:14px"><input type="hidden" name="p" value="licenses">'
        . '<input type="search" name="q" value="' . ra_h($q) . '" placeholder="Search key, email or note" aria-label="Search licenses" style="flex:1 1 240px">'
        . '<select name="source" data-auto aria-label="Source"><option value="">All sources</option>';
    foreach (['shop' => 'Shop', 'supportkori' => 'SupportKori', 'admin' => 'Masher Hisab keys', 'blocked' => 'Blocked only'] as $k => $v) {
        echo '<option value="' . $k . '"' . ($source === $k ? ' selected' : '') . '>' . $v . '</option>';
    }
    echo '</select><select name="status" data-auto aria-label="Status"><option value="">All statuses</option>';
    foreach (['active' => 'Active', 'unused' => 'Unused', 'removed' => 'Removed from account', 'blocked' => 'Blocked'] as $k => $v) {
        echo '<option value="' . $k . '"' . ($status === $k ? ' selected' : '') . '>' . $v . '</option>';
    }
    echo '</select><button class="btn btn-dark" type="submit">Search</button></form>';

    echo '<div class="tbl-wrap"><table><thead><tr><th>Key</th><th>Source</th><th>Status</th><th>Used by</th><th>Date</th><th>Actions</th></tr></thead><tbody>';
    if (!$rows) {
        echo '<tr><td colspan="6" class="empty">No licenses found.</td></tr>';
    }
    foreach ($rows as $k) {
        $f = ['key' => $k['key'], 'back' => $back];
        $used = [];
        foreach ($k['users'] as $u) {
            $used[] = '<a href="' . ra_url('user', ['uid' => $u['uid']]) . '">' . ra_h($u['email']) . '</a>';
        }
        $usedHtml = $used ? implode('<br>', $used) : ($k['owner'] !== '' ? '<span class="muted">' . ra_h($k['owner']) . ' (removed)</span>' : '<span class="muted">—</span>');
        $note = (string) ($k['admin']['note'] ?? '');
        $statusLabel = ['active' => 'Active', 'unused' => 'Unused', 'removed' => 'Removed', 'blocked' => 'Blocked'][$k['status']];
        echo '<tr><td><code>' . ra_h($k['key']) . '</code> <button class="btn btn-sm" type="button" data-copy="' . ra_h($k['key']) . '" aria-label="Copy key">Copy</button>'
            . ($note !== '' ? '<div class="muted small">' . ra_h($note) . '</div>' : '') . ($k['reason'] !== '' ? '<div class="small" style="color:var(--bad)">' . ra_h($k['reason']) . '</div>' : '') . '</td>'
            . '<td>' . ra_pill($k['source'], ra_source_label($k['source'])) . '</td><td>' . ra_pill($k['status'], $statusLabel) . '</td>'
            . '<td class="wrap">' . $usedHtml . '</td><td>' . ra_date($k['activated']) . '</td><td><div class="row" style="flex-wrap:nowrap">';
        if ($k['status'] === 'active') {
            echo ra_post_btn('key_deactivate', 'Deactivate', $f, 'btn btn-sm', 'Remove this key from the account(s) using it? They can activate it again.');
        }
        if ($k['blocked']) {
            echo ra_post_btn('key_unblock', 'Unblock', $f);
        } else {
            echo ra_post_btn('key_block', 'Block', $f, 'btn btn-sm btn-bad', 'Block this key? It is removed from every account and cannot be used again.');
        }
        if ($k['admin'] !== null && !empty($k['admin']['uid'])) {
            echo ra_post_btn('key_unbind', 'Free', $f, 'btn btn-sm', 'Free this key so another account can use it?');
        }
        echo ra_post_btn('key_delete', 'Delete', $f, 'btn btn-sm btn-bad', $k['source'] === 'admin' ? 'Delete this key for good?' : 'Remove this key from accounts and from this list? (It stays valid at ' . ra_source_label($k['source']) . '.)');
        echo '</div></td></tr>';
    }
    echo '</tbody></table></div>' . ra_pager($page, $pages, $qs)
        . '<p class="muted small">Shop and SupportKori keys appear once someone activates them in the app. To refund or disable a shop key for good, also turn it off in the shop admin.</p>';
    ra_bottom();
}

function ra_page_backups(): void
{
    $list = ra_backup_list();
    $back = ra_url('backups');
    $userDirs = glob(RA_API . '/userbackups/*', GLOB_ONLYDIR) ?: [];
    $userFiles = 0;
    $userBytes = 0;
    foreach ($userDirs as $d) {
        foreach (glob("$d/*.mhbackup") ?: [] as $f) {
            $userFiles++;
            $userBytes += (int) filesize($f);
        }
    }
    $total = array_sum(array_column($list, 'size'));
    ra_top('Backups', 'backups', 'Full database backups of every user\'s data', ra_post_btn('backup_make', 'Back up now', ['back' => $back], 'btn btn-main'));

    echo '<div class="grid g3" style="margin-bottom:14px">'
        . '<div class="card stat"><div class="k">Database backups</div><div class="v">' . count($list) . '</div><div class="s">' . ra_size($total) . ' · newest ' . ($list ? ra_ago($list[0]['time'] * 1000) : 'never') . '</div></div>'
        . '<div class="card stat"><div class="k">Users\' own app backups</div><div class="v">' . ra_num($userFiles) . '</div><div class="s">' . ra_size($userBytes) . ' from ' . count($userDirs) . ' users (see each user)</div></div>'
        . '<div class="card"><div class="row between"><div><h2 style="margin-bottom:4px">Daily automatic backup</h2><div class="muted small">Made once a day when someone syncs. The newest 14 are kept.</div></div>';
    $on = ra_autobackup_on();
    echo ra_post_btn('autobackup', $on ? 'Turn off' : 'Turn on', ['on' => $on ? '' : '1', 'back' => $back], $on ? 'btn btn-sm' : 'btn btn-sm btn-main') . '</div>'
        . '<div style="margin-top:8px">' . ra_pill($on ? 'active' : 'expired', $on ? 'On' : 'Off') . '</div></div></div>';

    echo '<div class="tbl-wrap"><table><thead><tr><th>Backup</th><th>Size</th><th>Made</th><th>Actions</th></tr></thead><tbody>';
    if (!$list) {
        echo '<tr><td colspan="4" class="empty">No backups yet. Press “Back up now”.</td></tr>';
    }
    foreach ($list as $b) {
        $f = ['file' => $b['name'], 'back' => $back];
        echo '<tr><td class="mono">' . ra_h($b['name']) . (str_contains($b['name'], 'before-restore') ? ' ' . ra_pill('removed', 'Safety copy') : '') . '</td><td>' . ra_size($b['size']) . '</td><td title="' . ra_h(ra_when($b['time'] * 1000)) . '">' . ra_ago($b['time'] * 1000) . '</td>'
            . '<td><div class="row" style="flex-wrap:nowrap">'
            . '<form method="post" class="inline row" style="flex-wrap:nowrap" data-confirm="Restore this backup? All current data is replaced by it.">' . ra_csrf()
            . '<input type="hidden" name="do" value="backup_restore"><input type="hidden" name="file" value="' . ra_h($b['name']) . '"><input type="hidden" name="back" value="' . ra_h($back) . '"><input type="hidden" name="reload" value="1">'
            . '<input type="text" name="confirm" placeholder="Type RESTORE" aria-label="Type RESTORE to confirm" style="width:130px;height:32px"><button class="btn btn-sm btn-dark" type="submit">Restore</button></form>'
            . ra_post_btn('backup_delete', 'Delete', $f, 'btn btn-sm btn-bad', 'Delete this backup file?') . '</div></td></tr>';
    }
    echo '</tbody></table></div>';

    {
        echo '<div class="card" style="margin-top:14px"><h2>Download a locked copy to your phone or PC</h2>'
            . '<p class="muted" style="margin-top:0">The file is locked with a password you choose. Nobody can open or read it without that password — keep the password safe, it cannot be recovered. You can restore the file here, or on a new server if this hosting is ever lost.</p>'
            . '<form method="post" class="row" data-download>' . ra_csrf() . '<input type="hidden" name="do" value="backup_locked"><input type="hidden" name="back" value="' . ra_h($back) . '">'
            . '<select name="file" aria-label="Backup to download" style="flex:1 1 260px"><option value="__now">' . ra_h('A new backup made now') . '</option>';
        foreach ($list as $b) {
            echo '<option value="' . ra_h($b['name']) . '">' . ra_h(ra_when($b['time'] * 1000)) . ' · ' . ra_size($b['size']) . (str_contains($b['name'], 'before-restore') ? ' · safety copy' : '') . '</option>';
        }
        echo '</select><input type="password" name="pass" minlength="8" required placeholder="Backup password" aria-label="Backup password" autocomplete="new-password" style="flex:1 1 160px">'
            . '<input type="password" name="pass2" minlength="8" required placeholder="Password again" aria-label="Backup password again" autocomplete="new-password" style="flex:1 1 160px">'
            . '<button class="btn btn-main" type="submit">Download locked copy</button></form></div>';
    }

    echo '<div class="grid g2" style="margin-top:14px"><div class="card"><h2>Restore from a file</h2>'
        . '<form method="post" enctype="multipart/form-data" class="stack" data-confirm="Restore this file? All current data is replaced by it.">' . ra_csrf()
        . '<input type="hidden" name="do" value="backup_upload"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<div class="field"><label for="file">Backup file (.mhdb locked copy or .sql.gz)</label><input id="file" type="file" name="file" accept=".mhdb,.gz" required></div>'
        . '<div class="field"><label for="rpass">Backup password (for a locked .mhdb file)</label><input id="rpass" type="password" name="pass" autocomplete="off"></div>'
        . '<label class="row" style="font-weight:500"><input type="checkbox" name="reload" value="1" checked> Make every phone download the restored data (recommended)</label>'
        . '<div class="row"><input type="text" name="confirm" placeholder="Type RESTORE" aria-label="Type RESTORE to confirm" style="width:150px"><button class="btn btn-dark" type="submit">Upload and restore</button></div></form></div>'
        . '<div class="card"><h2>How restore works</h2><ul class="muted" style="margin:0;padding-left:18px">'
        . '<li>The whole file is checked first. Only Masher Hisab tables can be restored.</li>'
        . '<li>A safety copy of the current data is saved before anything changes.</li>'
        . '<li>Phones then clear their copy and download the restored data. Changes made on a phone after the backup are lost.</li>'
        . '<li>Your admin login is never changed by a restore.</li></ul></div></div>';
    ra_bottom();
}

function ra_page_log(): void
{
    $q = trim((string) ($_GET['q'] ?? ''));
    $pdo = db();
    $where = '';
    $args = [];
    if ($q !== '') {
        $where = 'WHERE action LIKE ? OR target LIKE ? OR detail LIKE ? OR admin LIKE ?';
        $like = '%' . $q . '%';
        $args = [$like, $like, $like, $like];
    }
    $st = $pdo->prepare("SELECT COUNT(*) FROM mh_admin_log $where");
    $st->execute($args);
    $total = (int) $st->fetchColumn();
    $per = 100;
    $pages = max(1, (int) ceil($total / $per));
    $page = max(1, min($pages, (int) ($_GET['page'] ?? 1)));
    $st = $pdo->prepare("SELECT * FROM mh_admin_log $where ORDER BY id DESC LIMIT $per OFFSET " . (($page - 1) * $per));
    $st->execute($args);
    $rows = $st->fetchAll();
    ra_top('Activity log', 'log', 'Every admin sign-in and change, newest first');
    echo '<form method="get" class="row" style="margin-bottom:14px"><input type="hidden" name="p" value="log"><input type="search" name="q" value="' . ra_h($q) . '" placeholder="Search" aria-label="Search log" style="flex:1 1 240px"><button class="btn btn-dark" type="submit">Search</button></form>'
        . '<div class="tbl-wrap"><table><thead><tr><th>When</th><th>Admin</th><th>Action</th><th>On</th><th>Details</th><th>IP</th></tr></thead><tbody>';
    if (!$rows) {
        echo '<tr><td colspan="6" class="empty">Nothing logged yet.</td></tr>';
    }
    foreach ($rows as $r) {
        echo '<tr><td title="' . ra_h(ra_when($r['at'])) . '">' . ra_when($r['at']) . '</td><td>' . ra_h($r['admin']) . '</td><td><b>' . ra_h(str_replace('_', ' ', $r['action'])) . '</b></td>'
            . '<td class="wrap">' . ra_h($r['target']) . '</td><td class="wrap muted">' . ra_h($r['detail']) . '</td><td class="mono small">' . ra_h($r['ip']) . '</td></tr>';
    }
    echo '</tbody></table></div>' . ra_pager($page, $pages, ['p' => 'log', 'q' => $q]);
    ra_bottom();
}

function ra_page_settings(): void
{
    $a = ra_admin();
    $back = ra_url('settings');
    $status = ra_server_status();
    $pdo = db();
    $dbSize = (int) $pdo->query("SELECT COALESCE(SUM(data_length + index_length), 0) FROM information_schema.TABLES WHERE table_schema = DATABASE() AND table_name LIKE 'mh\\\\_%'")->fetchColumn();
    $recLeft = count(json_decode((string) $a['recovery'], true) ?: []);
    ra_top('Settings', 'settings', 'Your admin account and the server');

    echo '<div class="grid g2"><div class="stack">';
    echo '<div class="card"><h2>Your account</h2><div class="kv"><div>Username</div><div><b>' . ra_h($a['username']) . '</b></div><div>Last sign-in</div><div>' . ra_when($a['last_login']) . ' · ' . ra_h($a['last_ip']) . '</div>'
        . '<div>Recovery codes</div><div>' . $recLeft . ' left</div></div></div>';

    echo '<div class="card"><h2>Change password</h2><form method="post" class="stack">' . ra_csrf() . '<input type="hidden" name="do" value="password"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<div class="field"><label for="cur">Current password</label><input id="cur" type="password" name="current" required autocomplete="current-password"></div>'
        . '<div class="field"><label for="new">New password (10+ characters)</label><input id="new" type="password" name="new" required minlength="10" autocomplete="new-password"></div>'
        . '<div class="field"><label for="new2">New password again</label><input id="new2" type="password" name="new2" required minlength="10" autocomplete="new-password"></div>'
        . '<div class="field"><label for="code1">6-digit code</label><input id="code1" type="text" name="code" inputmode="numeric" maxlength="6" required autocomplete="one-time-code" style="width:140px"></div>'
        . '<button class="btn btn-dark" type="submit">Change password</button></form></div>';

    $trusted = ra_trust_list((int) $a['id']);
    $here = ra_trust_current_id();
    echo '<div class="card"><div class="card-head"><h2>Remembered devices</h2>' . ($trusted ? ra_post_btn('trust_forget', 'Forget all', ['id' => '0', 'back' => $back], 'btn btn-sm btn-bad', 'Forget every device? Each will need the 6-digit code again.') : '') . '</div>'
        . '<p class="muted" style="margin-top:0">These skip the 6-digit code for ' . RA_TRUST_DAYS . ' days. Your password is still needed. You stay signed in for up to 8 hours.</p>';
    if (!$trusted) {
        echo '<p class="muted small" style="margin:0">None yet. Tick “Remember this device” when you enter the code.</p>';
    }
    foreach ($trusted as $d) {
        echo '<div class="row between" style="padding:9px 0;border-top:1px solid var(--line2)"><div><b>' . ra_h($d['name']) . '</b>' . ((int) $d['id'] === $here ? ' ' . ra_pill('active', 'This device') : '')
            . '<div class="muted small">Last used ' . ra_ago($d['last_used']) . ' · ' . ra_h($d['ip']) . ' · until ' . ra_date($d['expires']) . '</div></div>'
            . ra_post_btn('trust_forget', 'Forget', ['id' => (string) $d['id'], 'back' => $back], 'btn btn-sm') . '</div>';
    }
    echo '</div>';

    echo '<div class="card"><h2>2-step sign-in</h2>';
    if (!empty($_SESSION['new_totp'])) {
        echo '<p class="muted" style="margin-top:0">Scan this in your new authenticator app, then type its code.</p><div class="qr"><div id="qr" data-uri="' . ra_h(ra_totp_uri($_SESSION['new_totp'], $a['username'])) . '"></div></div>'
            . '<p class="small muted">Key: <code style="word-break:break-all">' . ra_h(trim(chunk_split($_SESSION['new_totp'], 4, ' '))) . '</code></p>'
            . '<form method="post" class="row">' . ra_csrf() . '<input type="hidden" name="do" value="totp_finish"><input type="hidden" name="back" value="' . ra_h($back) . '">'
            . '<input type="text" name="code" inputmode="numeric" maxlength="6" required placeholder="6-digit code" aria-label="6-digit code" style="width:150px"><button class="btn btn-main" type="submit">Use this app</button></form>'
            . '<div style="margin-top:8px">' . ra_post_btn('totp_cancel', 'Cancel', ['back' => $back]) . '</div>';
    } else {
        echo '<form method="post" class="row" style="margin-bottom:12px">' . ra_csrf() . '<input type="hidden" name="do" value="recovery_new"><input type="hidden" name="back" value="' . ra_h($back) . '">'
            . '<input type="text" name="code" inputmode="numeric" maxlength="6" required placeholder="6-digit code" aria-label="6-digit code" style="width:150px"><button class="btn" type="submit">Make new recovery codes</button></form>'
            . '<form method="post" class="row">' . ra_csrf() . '<input type="hidden" name="do" value="totp_start"><input type="hidden" name="back" value="' . ra_h($back) . '">'
            . '<input type="password" name="current" required placeholder="Your password" aria-label="Your password" style="width:180px"><button class="btn" type="submit">Move to a new phone</button></form>';
    }
    echo '</div></div><div class="stack">';

    echo '<div class="card"><div class="card-head"><h2>Server files</h2>' . (ra_server_needs_update() ? ra_post_btn('server_update', 'Update server', ['back' => $back], 'btn btn-sm btn-main', 'Copy the new API files into masher-api? The old ones are kept.') : ra_pill('active', 'Up to date')) . '</div>'
        . '<div class="kv">';
    $labels = ['same' => ['active', 'Up to date'], 'changed' => ['expired', 'Update ready'], 'missing' => ['expired', 'Missing'], 'no-source' => ['new', 'Not in this build']];
    foreach ($status as $f => $s) {
        echo '<div class="mono">' . ra_h($f) . '</div><div>' . ra_pill($labels[$s][0], $labels[$s][1]) . '</div>';
    }
    echo '</div><p class="muted small" style="margin:10px 0 0">Every website update brings the newest masher-api files. config.php is never changed.</p></div>';

    echo '<div class="card"><h2>Server</h2><div class="kv"><div>API folder</div><div class="mono" style="word-break:break-all">' . ra_h(RA_API) . '</div>'
        . '<div>PHP</div><div>' . ra_h(PHP_VERSION) . '</div><div>Database size</div><div>' . ra_size($dbSize) . '</div>'
        . '<div>Panel version</div><div>' . RA_VERSION . '</div><div>Server time</div><div>' . date('d M Y, g:i A') . ' (Dhaka)</div></div></div>';

    echo '<div class="card"><h2>Daily backup with cron (optional)</h2><p class="muted" style="margin-top:0">Automatic backups already run when people sync. For a fixed time every night, add this in cPanel → Cron Jobs:</p>'
        . '<code style="display:block;word-break:break-all;background:#FAFCFB;border:1px solid var(--line);padding:10px;border-radius:10px">php ' . ra_h(RA_API) . '/cron.php</code></div>';
    echo '</div></div>';
    if (!empty($_SESSION['new_totp'])) {
        echo '<script src="assets/qrcode.js?v=' . RA_VERSION . '"></script>';
    }
    ra_bottom();
}


function ra_page_messages(): void
{
    $back = ra_url('messages');
    ra_top('Messages', 'messages', 'Push notifications and emails to your users');
    if (!function_exists('message_send')) {
        echo '<div class="card"><p>Open <a href="' . ra_url('settings') . '">Settings</a> and tap <b>Update server</b> first.</p></div>';
        ra_bottom();
        return;
    }
    push_schema();
    $pdo = db();
    $phones = (int) $pdo->query('SELECT COUNT(*) FROM mh_push')->fetchColumn();
    $emails = (int) $pdo->query("SELECT COUNT(DISTINCT LOWER(email)) FROM mh_users WHERE email <> ''")->fetchColumn();
    $optout = (int) $pdo->query('SELECT COUNT(*) FROM mh_mail_optout')->fetchColumn();
    $hasKey = fcm_account() !== null;
    $flags = promo_flags();

    echo '<div class="grid g2"><div class="stack">';
    echo '<div class="card"><h2>Send a message</h2><form method="post" class="stack" data-confirm="Send this now? (Everyone, unless a test email is filled in.)">' . ra_csrf() . '<input type="hidden" name="do" value="msg_send"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<div class="field"><label for="tp">Ready-made message</label><select id="tp" name="tpl"><option value="">— Write my own below —</option>'
        . '<option value="update">Update available</option><option value="collection">New feature: Money collection</option>'
        . '<option value="inflation">New feature: My inflation</option><option value="somiti">Somiti got better</option><option value="tip">A random tip</option></select>'
        . '<div class="muted small">Used only when Title and Message are empty.</div></div>'
        . '<div class="field"><label for="mt">Title</label><input id="mt" name="title" maxlength="120" placeholder="e.g. New: Money collection"></div>'
        . '<div class="field"><label for="mb">Short message (shows in the notification)</label><textarea id="mb" name="body" rows="2" maxlength="240" placeholder="One or two lines"></textarea></div>'
        . '<div class="field"><label for="md">Details (in the app and the email)</label><textarea id="md" name="details" rows="6" placeholder="• Point one&#10;• Point two&#10;&#10;Where to find it: More › …"></textarea></div>'
        . '<div class="field"><label for="mo">Send a test only to (email)</label><input id="mo" name="only" type="email" placeholder="Leave empty to send to everyone" value="' . ra_h((string) ($_SESSION['msg_test'] ?? '')) . '"></div>'
        . '<label class="row"><input type="checkbox" name="push" value="1"' . ($hasKey ? ' checked' : ' disabled') . '> App notification to ' . $phones . ' phone(s)' . ($hasKey ? '' : ' <span class="muted small">(add the Firebase key first)</span>') . '</label>'
        . '<label class="row"><input type="checkbox" name="mail" value="1"> Email to ' . max(0, $emails - $optout) . ' user(s)</label>'
        . '<button class="btn btn-main" type="submit">Send now</button></form></div>';

    echo '<div class="card"><h2>Automatic feature tips</h2><p class="muted" style="margin-top:0">The app’s features, one tip at a time.</p>'
        . '<form method="post" class="stack">' . ra_csrf() . '<input type="hidden" name="do" value="promo_set"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<label class="row"><input type="checkbox" name="push" value="1"' . ($flags['push'] ? ' checked' : '') . '> App notification, twice a day</label>'
        . '<label class="row"><input type="checkbox" name="mail" value="1"' . ($flags['mail'] ? ' checked' : '') . '> Email, once a day</label>'
        . '<button class="btn" type="submit">Save</button></form>'
        . '<p class="muted small">Add these in cPanel → Cron Jobs (once):</p>'
        . '<code style="display:block;word-break:break-all;background:#FAFCFB;border:1px solid var(--line);padding:10px;border-radius:10px">0 10,19 * * * /usr/local/bin/php -q ' . ra_h(RA_API) . '/promo.php push &gt;/dev/null 2&gt;&amp;1<br>0 11 * * * /usr/local/bin/php -q ' . ra_h(RA_API) . '/promo.php mail &gt;/dev/null 2&gt;&amp;1</code><p class="muted small">The end part stops cron from emailing you each time.</p></div>';
    echo '</div><div class="stack">';

    echo '<div class="card"><div class="card-head"><h2>Firebase key</h2>' . ra_pill($hasKey ? 'active' : 'expired', $hasKey ? 'Ready' : 'Not set') . '</div>'
        . '<p class="muted" style="margin-top:0">Needed once for app notifications. Firebase console → Project settings → Service accounts → Generate new private key. Open the downloaded file, copy everything and paste it here.</p>'
        . '<form method="post" class="stack">' . ra_csrf() . '<input type="hidden" name="do" value="fcm_key"><input type="hidden" name="back" value="' . ra_h($back) . '">'
        . '<textarea name="json" rows="5" required placeholder=\'{ "type": "service_account", ... }\' style="font-family:monospace;font-size:12px"></textarea>'
        . '<button class="btn" type="submit">Save key</button></form><p class="muted small">Kept only on your server, in a folder the web can’t open.</p></div>';

    echo '<div class="card"><h2>Sent</h2>';
    $rows = $pdo->query('SELECT * FROM mh_messages ORDER BY id DESC LIMIT 30')->fetchAll();
    if (!$rows) {
        echo '<p class="muted small" style="margin:0">Nothing sent yet.</p>';
    }
    foreach ($rows as $r) {
        echo '<div style="padding:9px 0;border-top:1px solid var(--line2)"><div class="row between"><b>' . ra_h($r['title']) . '</b>' . ra_pill($r['kind'] === 'auto' ? 'trial' : ($r['kind'] === 'test' ? 'new' : 'active'), ucfirst((string) $r['kind'])) . '</div>'
            . '<div class="muted small">' . ra_when($r['created']) . ' · ' . (int) $r['pushed'] . ' push · ' . (int) $r['mailed'] . ' email</div></div>';
    }
    echo '<p class="muted small">' . $optout . ' people unsubscribed from emails.</p></div>';
    echo '</div></div>';
    ra_bottom();
}
