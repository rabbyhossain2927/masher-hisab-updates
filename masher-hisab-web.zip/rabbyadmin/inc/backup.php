<?php
// Masher Hisab admin panel: database backups and restore.
// Uses the same folder as masher-api (backups/), so daily backups show here too.
declare(strict_types=1);

const RA_BACKUP_KEEP = 14;
const RA_BACKUP_SKIP = ['mh_admins', 'mh_admin_attempts'];
const RA_BACKUP_RE = '/^masher-backup-[0-9A-Za-z\-]+\.sql\.gz$/';

function ra_backup_dir(): string
{
    $dir = RA_API . '/backups';
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    if (!file_exists("$dir/.htaccess")) {
        @file_put_contents("$dir/.htaccess", "Require all denied\nDeny from all\n");
    }
    if (!file_exists("$dir/index.php")) {
        @file_put_contents("$dir/index.php", "<?php // nothing here\n");
    }
    return $dir;
}

function ra_backup_tables(): array
{
    $out = [];
    foreach (db()->query("SHOW TABLES LIKE 'mh\\\\_%'")->fetchAll(PDO::FETCH_NUM) as $r) {
        if (!in_array($r[0], RA_BACKUP_SKIP, true)) {
            $out[] = $r[0];
        }
    }
    return $out;
}

/** Writes a gzipped SQL dump. Returns the number of rows. */
function ra_backup_write(string $path): int
{
    $pdo = db();
    $gz = gzopen($path, 'wb6');
    if ($gz === false) {
        throw new RuntimeException('Cannot write the backup file. Check that masher-api/backups can be written.');
    }
    $rows = 0;
    gzwrite($gz, "-- Masher Hisab database backup\n-- " . date('Y-m-d H:i:s') . "\n\nSET NAMES utf8mb4;\nSET FOREIGN_KEY_CHECKS = 0;\n\n");
    foreach (ra_backup_tables() as $table) {
        $create = $pdo->query("SHOW CREATE TABLE `$table`")->fetch(PDO::FETCH_NUM);
        gzwrite($gz, "DROP TABLE IF EXISTS `$table`;\n" . $create[1] . ";\n\n");
        $st = $pdo->query("SELECT * FROM `$table`", PDO::FETCH_ASSOC);
        $batch = [];
        $cols = null;
        while ($r = $st->fetch()) {
            if ($cols === null) {
                $cols = '`' . implode('`, `', array_keys($r)) . '`';
            }
            $vals = [];
            foreach ($r as $v) {
                $vals[] = $v === null ? 'NULL' : $pdo->quote((string) $v);
            }
            $batch[] = '(' . implode(', ', $vals) . ')';
            $rows++;
            if (count($batch) >= 200) {
                gzwrite($gz, "INSERT INTO `$table` ($cols) VALUES\n" . implode(",\n", $batch) . ";\n");
                $batch = [];
            }
        }
        if ($batch) {
            gzwrite($gz, "INSERT INTO `$table` ($cols) VALUES\n" . implode(",\n", $batch) . ";\n");
        }
        gzwrite($gz, "\n");
    }
    gzwrite($gz, "SET FOREIGN_KEY_CHECKS = 1;\n");
    gzclose($gz);
    return $rows;
}

function ra_backup_list(): array
{
    $out = [];
    foreach (glob(ra_backup_dir() . '/masher-backup-*.sql.gz') ?: [] as $f) {
        $out[] = ['name' => basename($f), 'size' => (int) filesize($f), 'time' => (int) filemtime($f)];
    }
    usort($out, fn ($a, $b) => $b['time'] <=> $a['time']);
    return $out;
}

/** Makes a stored backup and keeps the newest ones. */
function ra_backup_make(string $tag = ''): array
{
    $dir = ra_backup_dir();
    $tag = preg_replace('/[^a-z0-9]/', '', strtolower($tag)) ?? '';
    $name = 'masher-backup-' . date('Y-m-d-His') . ($tag !== '' ? "-$tag" : '') . '.sql.gz';
    $rows = ra_backup_write("$dir/$name");
    foreach (array_slice(ra_backup_list(), RA_BACKUP_KEEP) as $old) {
        @unlink("$dir/" . $old['name']);
    }
    return ['name' => $name, 'rows' => $rows];
}

function ra_backup_path(string $name): ?string
{
    $name = basename($name);
    $p = ra_backup_dir() . '/' . $name;
    return (preg_match(RA_BACKUP_RE, $name) && is_file($p)) ? $p : null;
}

/**
 * Reads a backup and returns its statements, or throws when the file is
 * not a Masher Hisab backup. Only mh_ tables are allowed; admin sign-in
 * tables are skipped.
 */
function ra_backup_statements(string $path): array
{
    $gz = @gzopen($path, 'rb');
    if ($gz === false) {
        throw new RuntimeException('This file could not be opened. Choose a .sql.gz backup.');
    }
    $stmts = [];
    $buf = '';
    $seenTable = false;
    while (!gzeof($gz)) {
        $line = gzgets($gz, 1 << 22);
        if ($line === false) {
            break;
        }
        if ($buf === '' && (trim($line) === '' || str_starts_with(ltrim($line), '--'))) {
            continue;
        }
        $buf .= $line;
        if (str_ends_with(rtrim($line), ';')) {
            $stmts[] = trim($buf);
            $buf = '';
        }
    }
    gzclose($gz);
    if (trim($buf) !== '') {
        throw new RuntimeException('The backup file is cut off (it does not end properly).');
    }
    $ok = [];
    foreach ($stmts as $s) {
        if (preg_match('/^SET (NAMES utf8mb4|FOREIGN_KEY_CHECKS = [01]);$/', $s)) {
            $ok[] = $s;
            continue;
        }
        if (!preg_match('/^(DROP TABLE IF EXISTS|CREATE TABLE|INSERT INTO) `(mh_[a-z0-9_]+)`/', $s, $m)) {
            throw new RuntimeException('This is not a Masher Hisab backup (unexpected command found).');
        }
        if (in_array($m[2], RA_BACKUP_SKIP, true)) {
            continue;
        }
        $seenTable = $seenTable || $m[2] === 'mh_docs';
        $ok[] = $s;
    }
    if (!$seenTable) {
        throw new RuntimeException('This backup has no Masher Hisab data in it.');
    }
    return $ok;
}

/** Restores a backup file. Returns the number of commands run. */
function ra_backup_restore(string $path, bool $reloadPhones): int
{
    $stmts = ra_backup_statements($path);
    @set_time_limit(600);
    $pdo = db();
    foreach ($stmts as $s) {
        $pdo->exec($s);
    }
    if ($reloadPhones) {
        // Every phone clears its copy and downloads the restored data.
        $pdo->exec('UPDATE mh_users SET wipe_gen = wipe_gen + 1');
    }
    return count($stmts);
}

// ------------------------------------------------ locked (encrypted) copies
// A copy you keep on your phone or PC: AES-256-GCM, key from your own
// backup password (PBKDF2-SHA256). Without the password the file is unreadable,
// and you can restore it on any server — even if this hosting is gone.

const RA_LOCK_MAGIC = 'MHDB1';
const RA_LOCK_ROUNDS = 200000;

function ra_lock_ready(): bool
{
    return function_exists('openssl_encrypt') && in_array('aes-256-gcm', openssl_get_cipher_methods(), true);
}

function ra_backup_lock(string $plain, string $pass): string
{
    $salt = random_bytes(16);
    $iv = random_bytes(12);
    $key = hash_pbkdf2('sha256', $pass, $salt, RA_LOCK_ROUNDS, 32, true);
    $tag = '';
    $enc = openssl_encrypt($plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, RA_LOCK_MAGIC, 16);
    if ($enc === false) {
        throw new RuntimeException('Could not lock the backup on this server.');
    }
    return RA_LOCK_MAGIC . $salt . $iv . $tag . $enc;
}

function ra_is_locked(string $path): bool
{
    $h = @fopen($path, 'rb');
    $head = $h ? (string) fread($h, 5) : '';
    if ($h) {
        fclose($h);
    }
    return $head === RA_LOCK_MAGIC;
}

/** Unlocks a .mhdb file into a temporary .sql.gz. Returns its path. */
function ra_backup_unlock(string $path, string $pass): string
{
    $data = (string) file_get_contents($path);
    if (strlen($data) < 50 || !str_starts_with($data, RA_LOCK_MAGIC)) {
        throw new RuntimeException('This is not a locked Masher Hisab backup.');
    }
    $salt = substr($data, 5, 16);
    $iv = substr($data, 21, 12);
    $tag = substr($data, 33, 16);
    $key = hash_pbkdf2('sha256', $pass, $salt, RA_LOCK_ROUNDS, 32, true);
    $plain = openssl_decrypt(substr($data, 49), 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, RA_LOCK_MAGIC);
    if ($plain === false) {
        throw new RuntimeException('Wrong backup password (or the file is damaged).');
    }
    $tmp = ra_backup_dir() . '/.unlock-' . bin2hex(random_bytes(6)) . '.sql.gz';
    file_put_contents($tmp, $plain);
    return $tmp;
}

function ra_autobackup_on(): bool
{
    return !file_exists(RA_API . '/cache/autobackup.off');
}

function ra_autobackup_set(bool $on): void
{
    $f = RA_API . '/cache/autobackup.off';
    if ($on) {
        @unlink($f);
    } else {
        @file_put_contents($f, (string) time());
    }
}
