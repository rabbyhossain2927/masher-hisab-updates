<?php
// Masher Hisab admin panel: page frame, charts and small view helpers.
declare(strict_types=1);

const RA_ICONS = [
    'dashboard' => '<path d="M3 13h8V3H3zM13 21h8V11h-8zM3 21h8v-6H3zM13 3v6h8V3z"/>',
    'users' => '<path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.9M16 3.1a4 4 0 0 1 0 7.8"/>',
    'licenses' => '<circle cx="7.5" cy="15.5" r="4.5"/><path d="M10.7 12.3 21 2M16 7l3 3M14 9l2 2"/>',
    'backups' => '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M3 5v14c0 1.7 4 3 9 3s9-1.3 9-3V5M3 12c0 1.7 4 3 9 3s9-1.3 9-3"/>',
    'log' => '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6M8 13h8M8 17h8M8 9h2"/>',
    'settings' => '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
    'messages' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    'logout' => '<path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4M16 17l5-5-5-5M21 12H9"/>',
    'install' => '<path d="M12 3v12M7 10l5 5 5-5M5 21h14"/>',
    'site' => '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15 15 0 0 1 0 20M12 2a15 15 0 0 0 0 20"/>',
];

function ra_icon(string $name): string
{
    return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' . (RA_ICONS[$name] ?? '') . '</svg>';
}

function ra_top(string $title, string $active, string $sub = '', string $actions = ''): void
{
    $nav = ['dashboard' => 'Dashboard', 'users' => 'Users', 'licenses' => 'Licenses', 'backups' => 'Backups', 'messages' => 'Messages', 'log' => 'Activity log', 'settings' => 'Settings'];
    echo '<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<title>' . ra_h($title) . ' · Masher Hisab Admin</title><meta name="robots" content="noindex, nofollow">'
        . '<link rel="manifest" href="manifest.webmanifest"><meta name="theme-color" content="#0D2E21">'
        . '<link rel="icon" type="image/png" href="assets/icon-192.png"><link rel="apple-touch-icon" href="assets/icon-180.png">'
        . '<meta name="apple-mobile-web-app-capable" content="yes"><meta name="mobile-web-app-capable" content="yes">'
        . '<meta name="apple-mobile-web-app-title" content="MH Admin"><meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">'
        . '<link rel="stylesheet" href="assets/admin.css?v=' . RA_VERSION . '"></head><body><div class="app">'
        . '<aside class="side"><div class="brand"><span class="dot">M</span><div>Masher Hisab<small>Admin panel</small></div></div>'
        . '<button class="btn btn-sm menu-btn" type="button" aria-label="Menu">Menu</button><nav>';
    foreach ($nav as $k => $label) {
        echo '<a href="' . ra_url($k) . '"' . ($k === $active ? ' class="on" aria-current="page"' : '') . '>' . ra_icon($k) . ra_h($label) . '</a>';
    }
    echo '<div class="grow"></div><button class="install-btn" type="button" hidden>' . ra_icon('install') . 'Install as app</button>'
        . '<a href="../" target="_blank" rel="noopener">' . ra_icon('site') . 'Open web app</a>'
        . '<a href="?p=logout">' . ra_icon('logout') . 'Sign out</a></nav></aside><main class="main">'
        . '<div class="top"><div><h1>' . ra_h($title) . '</h1>' . ($sub !== '' ? '<p>' . $sub . '</p>' : '') . '</div>'
        . ($actions !== '' ? '<div class="row">' . $actions . '</div>' : '') . '</div>';
    foreach (ra_take_flash() as [$k, $m]) {
        echo '<div class="flash ' . ra_h($k) . '">' . ra_h($m) . '</div>';
    }
}

function ra_bottom(): void
{
    echo '</main></div><script src="assets/admin.js?v=' . RA_VERSION . '"></script></body></html>';
}

function ra_pill(string $state, string $label = ''): string
{
    $map = [
        'licensed' => 'p-ok', 'active' => 'p-ok', 'trial' => 'p-info', 'expired' => 'p-warn', 'new' => 'p-gray',
        'blocked' => 'p-bad', 'unused' => 'p-gray', 'removed' => 'p-warn',
        'shop' => 'p-info', 'supportkori' => 'p-warn', 'admin' => 'p-ok', 'android' => 'p-ok', 'web' => 'p-info',
    ];
    $text = $label !== '' ? $label : ucfirst($state);
    return '<span class="pill ' . ($map[$state] ?? 'p-gray') . '">' . ra_h($text) . '</span>';
}

function ra_source_label(string $s): string
{
    return ['shop' => 'Shop', 'supportkori' => 'SupportKori', 'admin' => 'Masher Hisab', 'blocked' => 'Blocked only'][$s] ?? ucfirst($s);
}

/** A small action button that posts. $fields are extra hidden inputs. */
function ra_post_btn(string $do, string $label, array $fields = [], string $cls = 'btn btn-sm', string $confirm = ''): string
{
    $h = '<form method="post" class="inline"' . ($confirm !== '' ? ' data-confirm="' . ra_h($confirm) . '"' : '') . '>' . ra_csrf()
        . '<input type="hidden" name="do" value="' . ra_h($do) . '">';
    foreach ($fields as $k => $v) {
        $h .= '<input type="hidden" name="' . ra_h($k) . '" value="' . ra_h($v) . '">';
    }
    return $h . '<button class="' . ra_h($cls) . '" type="submit">' . ra_h($label) . '</button></form>';
}

/** Bar chart as plain SVG (no outside scripts). */
function ra_bars(array $labels, array $values, string $color = '#1DBF73', int $h = 180): string
{
    $n = max(1, count($values));
    $max = max($values ?: [0]);
    $max = $max <= 4 ? 4 : (int) (ceil($max / 4) * 4);
    $w = 720;
    $padL = 34;
    $padB = 26;
    $cw = ($w - $padL) / $n;
    $bw = max(2, $cw * 0.66);
    $s = '<svg class="bars" viewBox="0 0 ' . $w . ' ' . $h . '" role="img" aria-label="Bar chart">';
    foreach ([0, 0.5, 1] as $f) {
        $y = round(($h - $padB) - ($h - $padB - 10) * $f, 1);
        $s .= '<line x1="' . $padL . '" x2="' . $w . '" y1="' . $y . '" y2="' . $y . '" stroke="#E6EDE9" stroke-width="1"/>'
            . '<text x="' . ($padL - 6) . '" y="' . ($y + 4) . '" text-anchor="end" font-size="11" fill="#55665D">' . round($max * $f) . '</text>';
    }
    foreach ($values as $i => $v) {
        $bh = ($h - $padB - 10) * ($v / $max);
        $x = $padL + $i * $cw + ($cw - $bw) / 2;
        $y = ($h - $padB) - $bh;
        $s .= '<rect x="' . round($x, 1) . '" y="' . round($y, 1) . '" width="' . round($bw, 1) . '" height="' . round(max($bh, $v > 0 ? 2 : 0), 1) . '" rx="3" fill="' . $color . '"><title>' . ra_h($labels[$i]) . ': ' . $v . '</title></rect>';
        $every = $n > 16 ? (int) ceil($n / 8) : 1;
        if (($i % $every === 0 && ($n - 1 - $i >= $every || $every === 1)) || $i === $n - 1) {
            $last = $i === $n - 1;
            $s .= '<text x="' . ($last ? $w : round($x + $bw / 2, 1)) . '" y="' . ($h - 8) . '" text-anchor="' . ($last ? 'end' : 'middle') . '" font-size="11" fill="#55665D">' . ra_h($labels[$i]) . '</text>';
        }
    }
    return $s . '</svg>';
}

/** Rows of label + bar share. $items = [label => count]. */
function ra_split(array $items, array $colors = []): string
{
    $total = max(1, array_sum($items));
    $h = '<div class="split">';
    $i = 0;
    $pal = $colors ?: ['#1DBF73', '#3D8BFF', '#F5A524', '#8B5CF6', '#FF4D8D', '#14C8B4', '#55665D'];
    foreach ($items as $label => $n) {
        $pct = round($n / $total * 100);
        $c = $pal[$i++ % count($pal)];
        $h .= '<div><div class="r"><span>' . ra_h($label === '' ? 'Unknown' : $label) . '</span><span class="muted">' . ra_num($n) . ' · ' . $pct . '%</span></div>'
            . '<div class="meter"><div style="width:' . $pct . '%;background:' . $c . '"></div></div></div>';
    }
    if (!$items) {
        $h .= '<div class="muted small">No data yet.</div>';
    }
    return $h . '</div>';
}

function ra_pager(int $page, int $pages, array $q): string
{
    if ($pages <= 1) {
        return '';
    }
    $h = '<div class="pager"><span class="muted small">Page ' . $page . ' of ' . $pages . '</span>';
    if ($page > 1) {
        $h .= '<a class="btn btn-sm" href="?' . ra_h(http_build_query(array_merge($q, ['page' => $page - 1]))) . '">Previous</a>';
    }
    if ($page < $pages) {
        $h .= '<a class="btn btn-sm" href="?' . ra_h(http_build_query(array_merge($q, ['page' => $page + 1]))) . '">Next</a>';
    }
    return $h . '</div>';
}

function ra_csv(string $name, array $head, array $rows): void
{
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="' . $name . '"');
    $f = fopen('php://output', 'w');
    fwrite($f, "\xEF\xBB\xBF");
    fputcsv($f, $head);
    foreach ($rows as $r) {
        // Stop spreadsheet formulas sneaking in through names.
        fputcsv($f, array_map(fn ($v) => is_string($v) && preg_match('/^[=+\-@]/', $v) ? "'" . $v : $v, $r));
    }
    fclose($f);
    exit;
}
