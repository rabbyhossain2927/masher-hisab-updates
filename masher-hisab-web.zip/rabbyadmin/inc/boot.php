<?php
// Masher Hisab admin panel: start-up, sign-in session and small helpers.
declare(strict_types=1);

const RA_VERSION = '1.0.1';
const RA_TRIAL_DAYS = 7;          // same as the app
const RA_IDLE_SECONDS = 28800;    // stay signed in up to 8 hours without clicks
const RA_TRUST_DAYS = 30;         // a remembered device skips the 6-digit code this long
const RA_MAX_FAILS = 5;           // wrong tries per 15 minutes per IP
define('RA_ROOT', dirname(__DIR__));

date_default_timezone_set('Asia/Dhaka');

header('X-Frame-Options: DENY');
header('X-Content-Type-Options: nosniff');
header('Referrer-Policy: no-referrer');
header('X-Robots-Tag: noindex, nofollow');
header("Content-Security-Policy: default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; frame-ancestors 'none'; form-action 'self'; base-uri 'none'");
header('Cache-Control: no-store');

/** Finds the masher-api folder (it holds config.php with the database details). */
function ra_api_dir(): ?string
{
    $local = RA_ROOT . '/config.local.php';
    if (is_file($local)) {
        $c = require $local;
        $d = is_array($c) ? rtrim((string) ($c['api_dir'] ?? ''), '/') : '';
        if ($d !== '' && @is_file("$d/lib.php") && @is_file("$d/config.php")) {
            return $d;
        }
    }
    $cands = [];
    $docroot = rtrim((string) ($_SERVER['DOCUMENT_ROOT'] ?? ''), '/');
    if ($docroot !== '') {
        $cands[] = dirname($docroot) . '/masher-api';
        $cands[] = dirname($docroot) . '/public_html/masher-api';
        $cands[] = $docroot . '/masher-api';
    }
    if (preg_match('#^(/home\d*/[^/]+)/#', RA_ROOT, $m)) {
        $cands[] = $m[1] . '/public_html/masher-api';
    }
    $home = (string) (getenv('HOME') ?: '');
    if ($home !== '') {
        $cands[] = rtrim($home, '/') . '/public_html/masher-api';
    }
    foreach ($cands as $c) {
        if (@is_file("$c/lib.php") && @is_file("$c/config.php")) {
            return realpath($c) ?: $c;
        }
    }
    return null;
}

function ra_h($s): string
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function ra_when($ms): string
{
    $ms = (int) $ms;
    return $ms <= 0 ? '—' : date('d M Y, g:i A', intdiv($ms, 1000));
}

function ra_date($ms): string
{
    $ms = (int) $ms;
    return $ms <= 0 ? '—' : date('d M Y', intdiv($ms, 1000));
}

function ra_ago($ms): string
{
    $ms = (int) $ms;
    if ($ms <= 0) {
        return 'never';
    }
    $s = max(0, time() - intdiv($ms, 1000));
    if ($s < 60) {
        return 'just now';
    }
    if ($s < 3600) {
        return intdiv($s, 60) . ' min ago';
    }
    if ($s < 86400) {
        return intdiv($s, 3600) . ' hr ago';
    }
    if ($s < 86400 * 60) {
        $d = intdiv($s, 86400);
        return $d . ($d === 1 ? ' day ago' : ' days ago');
    }
    return ra_date($ms);
}

function ra_num($n): string
{
    return number_format((float) $n);
}

function ra_size($bytes): string
{
    $b = (float) $bytes;
    if ($b >= 1073741824) {
        return round($b / 1073741824, 2) . ' GB';
    }
    if ($b >= 1048576) {
        return round($b / 1048576, 1) . ' MB';
    }
    return max(1, (int) round($b / 1024)) . ' KB';
}

function ra_ip(): string
{
    return substr((string) ($_SERVER['REMOTE_ADDR'] ?? ''), 0, 64);
}

function ra_url(string $page, array $q = []): string
{
    return '?' . http_build_query(array_merge(['p' => $page], $q));
}

function ra_redirect(string $url): void
{
    header('Location: ' . $url);
    exit;
}

function ra_flash(string $msg, string $kind = 'ok'): void
{
    $_SESSION['flash'][] = [$kind, $msg];
}

function ra_take_flash(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

// ------------------------------------------------------------ session

function ra_session_start(): void
{
    $path = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/rabbyadmin/index.php'))), '/') . '/';
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    // Own session folder, so shared-hosting cleanup does not sign you out early.
    $dir = RA_API . '/cache/sessions';
    if (!is_dir($dir)) {
        @mkdir($dir, 0700, true);
        @file_put_contents("$dir/.htaccess", "Require all denied\nDeny from all\n");
    }
    if (is_dir($dir) && is_writable($dir)) {
        session_save_path($dir);
    }
    ini_set('session.gc_maxlifetime', (string) RA_IDLE_SECONDS);
    ini_set('session.use_strict_mode', '1');
    session_name('mh_rabbyadmin');
    session_set_cookie_params(['lifetime' => RA_IDLE_SECONDS, 'path' => $path, 'secure' => $https, 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
    $GLOBALS['ra_cookie'] = ['path' => $path, 'secure' => $https];
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
}

function ra_csrf(): string
{
    return '<input type="hidden" name="csrf" value="' . ra_h($_SESSION['csrf']) . '">';
}

function ra_csrf_ok(): bool
{
    return hash_equals((string) ($_SESSION['csrf'] ?? ''), (string) ($_POST['csrf'] ?? ''));
}

/** The signed-in admin row, or null. */
function ra_admin(): ?array
{
    static $cache = false;
    if ($cache !== false) {
        return $cache;
    }
    $cache = null;
    $id = (int) ($_SESSION['admin_id'] ?? 0);
    if ($id <= 0 || empty($_SESSION['totp_ok'])) {
        return null;
    }
    if (time() - (int) ($_SESSION['seen'] ?? 0) > RA_IDLE_SECONDS) {
        $_SESSION = [];
        return null;
    }
    $_SESSION['seen'] = time();
    $st = db()->prepare('SELECT * FROM mh_admins WHERE id = ?');
    $st->execute([$id]);
    $cache = $st->fetch() ?: null;
    return $cache;
}

// ------------------------------------------------------------ tables

/** Admin tables, plus the usage tables in case the API has not made them yet. */
function ra_schema(): void
{
    $marker = RA_API . '/cache/ra_schema_v1';
    if (file_exists($marker)) {
        return;
    }
    $pdo = db();
    $pdo->exec("CREATE TABLE IF NOT EXISTS mh_admins (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        username VARCHAR(64) NOT NULL UNIQUE,
        pass_hash VARCHAR(255) NOT NULL,
        totp_secret VARCHAR(64) NOT NULL,
        totp_last BIGINT NOT NULL DEFAULT 0,
        recovery TEXT NOT NULL,
        created BIGINT NOT NULL,
        last_login BIGINT NOT NULL DEFAULT 0,
        last_ip VARCHAR(64) NOT NULL DEFAULT ''
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS mh_admin_attempts (
        ip VARCHAR(64) NOT NULL,
        at BIGINT NOT NULL,
        KEY ip_at (ip, at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS mh_admin_log (
        id BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        at BIGINT NOT NULL,
        admin VARCHAR(64) NOT NULL DEFAULT '',
        action VARCHAR(64) NOT NULL,
        target VARCHAR(255) NOT NULL DEFAULT '',
        detail TEXT NOT NULL,
        ip VARCHAR(64) NOT NULL DEFAULT '',
        KEY at (at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS mh_clients (
        uid VARCHAR(128) NOT NULL,
        device_id VARCHAR(64) NOT NULL,
        device_name VARCHAR(128) NOT NULL DEFAULT '',
        platform VARCHAR(16) NOT NULL DEFAULT '',
        app_version VARCHAR(32) NOT NULL DEFAULT '',
        first_seen BIGINT NOT NULL,
        last_seen BIGINT NOT NULL,
        PRIMARY KEY (uid, device_id),
        KEY last_seen (last_seen)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS mh_active_days (
        day DATE NOT NULL,
        uid VARCHAR(128) NOT NULL,
        PRIMARY KEY (day, uid)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    $pdo->exec("CREATE TABLE IF NOT EXISTS mh_key_blocks (
        license_key VARCHAR(80) NOT NULL PRIMARY KEY,
        reason VARCHAR(255) NOT NULL DEFAULT '',
        created BIGINT NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    if (!is_dir(RA_API . '/cache')) {
        @mkdir(RA_API . '/cache', 0755, true);
    }
    @file_put_contents($marker, (string) time());
}

function ra_log(string $action, string $target = '', string $detail = ''): void
{
    $a = ra_admin();
    db()->prepare('INSERT INTO mh_admin_log (at, admin, action, target, detail, ip) VALUES (?, ?, ?, ?, ?, ?)')
        ->execute([now_ms(), $a['username'] ?? (string) ($_SESSION['admin_name'] ?? ''), $action, substr($target, 0, 250), $detail, ra_ip()]);
}

// ------------------------------------------------------------ wrong tries

function ra_too_many_fails(): bool
{
    $st = db()->prepare('SELECT COUNT(*) FROM mh_admin_attempts WHERE ip = ? AND at > ?');
    $st->execute([ra_ip(), now_ms() - 15 * 60000]);
    return (int) $st->fetchColumn() >= RA_MAX_FAILS;
}

function ra_add_fail(): void
{
    $pdo = db();
    $pdo->prepare('INSERT INTO mh_admin_attempts (ip, at) VALUES (?, ?)')->execute([ra_ip(), now_ms()]);
    $pdo->prepare('DELETE FROM mh_admin_attempts WHERE at < ?')->execute([now_ms() - 86400000]);
    usleep(700000);
}

function ra_clear_fails(): void
{
    db()->prepare('DELETE FROM mh_admin_attempts WHERE ip = ?')->execute([ra_ip()]);
}

// ------------------------------------------------------------ remembered devices

function ra_schema_trust(): void
{
    $marker = RA_API . '/cache/ra_schema_v2';
    if (file_exists($marker)) {
        return;
    }
    db()->exec("CREATE TABLE IF NOT EXISTS mh_admin_devices (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        admin_id INT NOT NULL,
        token_hash CHAR(64) NOT NULL UNIQUE,
        name VARCHAR(160) NOT NULL DEFAULT '',
        ip VARCHAR(64) NOT NULL DEFAULT '',
        created BIGINT NOT NULL,
        last_used BIGINT NOT NULL,
        expires BIGINT NOT NULL,
        KEY admin_id (admin_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    @file_put_contents($marker, (string) time());
}

/** "Chrome on Android" style name from the browser. */
function ra_device_name(): string
{
    $ua = (string) ($_SERVER['HTTP_USER_AGENT'] ?? '');
    $os = 'Unknown device';
    foreach (['iPhone' => 'iPhone', 'iPad' => 'iPad', 'Android' => 'Android', 'Windows' => 'Windows PC', 'Mac OS X' => 'Mac', 'Linux' => 'Linux'] as $k => $v) {
        if (stripos($ua, $k) !== false) {
            $os = $v;
            break;
        }
    }
    $br = '';
    foreach (['Edg/' => 'Edge', 'OPR/' => 'Opera', 'SamsungBrowser' => 'Samsung Internet', 'Firefox/' => 'Firefox', 'CriOS' => 'Chrome', 'Chrome/' => 'Chrome', 'Safari/' => 'Safari'] as $k => $v) {
        if (stripos($ua, $k) !== false) {
            $br = $v;
            break;
        }
    }
    return $br !== '' ? "$br on $os" : $os;
}

function ra_trust_cookie(string $value, int $expires): void
{
    $c = $GLOBALS['ra_cookie'] ?? ['path' => '/', 'secure' => true];
    setcookie('mh_trust', $value, ['expires' => $expires, 'path' => $c['path'], 'secure' => $c['secure'], 'httponly' => true, 'samesite' => 'Strict']);
}

/** Remembers this browser for the admin, so the 6-digit code is skipped next time. */
function ra_trust_add(int $adminId): void
{
    ra_schema_trust();
    $token = bin2hex(random_bytes(32));
    $exp = time() + RA_TRUST_DAYS * 86400;
    db()->prepare('INSERT INTO mh_admin_devices (admin_id, token_hash, name, ip, created, last_used, expires) VALUES (?, ?, ?, ?, ?, ?, ?)')
        ->execute([$adminId, hash('sha256', $token), ra_device_name(), ra_ip(), now_ms(), now_ms(), $exp * 1000]);
    ra_trust_cookie($token, $exp);
}

/** Is this browser remembered for the admin? */
function ra_trust_check(int $adminId): bool
{
    ra_schema_trust();
    $token = (string) ($_COOKIE['mh_trust'] ?? '');
    if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
        return false;
    }
    $pdo = db();
    $pdo->prepare('DELETE FROM mh_admin_devices WHERE expires < ?')->execute([now_ms()]);
    $st = $pdo->prepare('SELECT id FROM mh_admin_devices WHERE token_hash = ? AND admin_id = ?');
    $st->execute([hash('sha256', $token), $adminId]);
    $id = $st->fetchColumn();
    if ($id === false) {
        return false;
    }
    $pdo->prepare('UPDATE mh_admin_devices SET last_used = ?, ip = ? WHERE id = ?')->execute([now_ms(), ra_ip(), $id]);
    return true;
}

function ra_trust_list(int $adminId): array
{
    ra_schema_trust();
    $st = db()->prepare('SELECT * FROM mh_admin_devices WHERE admin_id = ? AND expires > ? ORDER BY last_used DESC');
    $st->execute([$adminId, now_ms()]);
    return $st->fetchAll();
}

function ra_trust_current_id(): int
{
    $token = (string) ($_COOKIE['mh_trust'] ?? '');
    if (!preg_match('/^[0-9a-f]{64}$/', $token)) {
        return 0;
    }
    ra_schema_trust();
    $st = db()->prepare('SELECT id FROM mh_admin_devices WHERE token_hash = ?');
    $st->execute([hash('sha256', $token)]);
    return (int) ($st->fetchColumn() ?: 0);
}

function ra_trust_forget(int $adminId, int $id = 0): void
{
    ra_schema_trust();
    if ($id > 0) {
        db()->prepare('DELETE FROM mh_admin_devices WHERE admin_id = ? AND id = ?')->execute([$adminId, $id]);
    } else {
        db()->prepare('DELETE FROM mh_admin_devices WHERE admin_id = ?')->execute([$adminId]);
    }
}
