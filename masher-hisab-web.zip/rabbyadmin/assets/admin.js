// Masher Hisab admin panel: small helpers (no inline scripts, so the strict CSP holds).
(function () {
  document.addEventListener('submit', function (e) {
    var f = e.target;
    var msg = f.getAttribute('data-confirm');
    if (msg && !window.confirm(msg)) e.preventDefault();
  }, true);

  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-copy]');
    if (b) {
      var text = b.getAttribute('data-copy');
      if (navigator.clipboard) navigator.clipboard.writeText(text);
      var old = b.textContent;
      b.textContent = 'Copied';
      setTimeout(function () { b.textContent = old; }, 1200);
    }
    var m = e.target.closest('.menu-btn');
    if (m) document.querySelector('.side').classList.toggle('open');
  });

  // Auto-submit filter selects.
  document.querySelectorAll('select[data-auto]').forEach(function (s) {
    s.addEventListener('change', function () { s.form.submit(); });
  });

  // Install as an app (Android / desktop Chrome, and a tip for iPhone).
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js', { scope: './' }).catch(function () {});
  }
  var standalone = window.matchMedia('(display-mode: standalone)').matches || window.navigator.standalone === true;
  var installBtn = document.querySelector('.install-btn');
  var deferred = null;
  window.addEventListener('beforeinstallprompt', function (e) {
    e.preventDefault();
    deferred = e;
    if (installBtn) installBtn.hidden = false;
  });
  var isIos = /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
  if (installBtn && isIos && !standalone) installBtn.hidden = false;
  if (installBtn) {
    installBtn.addEventListener('click', function () {
      if (deferred) {
        deferred.prompt();
        deferred.userChoice.then(function () { deferred = null; installBtn.hidden = true; });
        return;
      }
      if (isIos && !document.querySelector('.ios-tip')) {
        var tip = document.createElement('div');
        tip.className = 'ios-tip';
        tip.textContent = 'On iPhone: open this page in Safari, tap the Share button, then "Add to Home Screen".';
        var ok = document.createElement('button');
        ok.className = 'btn btn-sm';
        ok.type = 'button';
        ok.textContent = 'OK';
        ok.addEventListener('click', function () { tip.remove(); });
        tip.appendChild(document.createElement('br'));
        tip.appendChild(ok);
        document.body.appendChild(tip);
      }
    });
  }
  window.addEventListener('appinstalled', function () { if (installBtn) installBtn.hidden = true; });

  // File downloads without leaving the page: an installed app (PWA) reloads
  // itself on a download navigation. Fetch the file, then save or share it.
  document.querySelectorAll('form[data-download]').forEach(function (f) {
    f.addEventListener('submit', function (e) {
      e.preventDefault();
      var btn = f.querySelector('button[type=submit]');
      var label = btn ? btn.textContent : '';
      if (btn) { btn.disabled = true; btn.textContent = 'Preparing…'; }
      var done = function () { if (btn) { btn.disabled = false; btn.textContent = label; } };
      fetch(location.href, { method: 'POST', body: new FormData(f), credentials: 'same-origin' })
        .then(function (r) {
          var cd = r.headers.get('Content-Disposition') || '';
          if (!r.ok || cd.indexOf('attachment') < 0) { location.reload(); return null; } // error message shows after reload
          var m = /filename="([^"]+)"/.exec(cd);
          var name = m ? m[1] : 'masher-backup.mhdb';
          return r.blob().then(function (b) { return { b: b, name: name }; });
        })
        .then(function (x) {
          done();
          if (!x) return;
          var file = new File([x.b], x.name, { type: 'application/octet-stream' });
          var touch = window.matchMedia('(pointer: coarse)').matches;
          if (touch && navigator.canShare && navigator.canShare({ files: [file] })) {
            // Phones: "Save to Files", Drive, etc.
            navigator.share({ files: [file], title: x.name }).catch(function () {});
            return;
          }
          var url = URL.createObjectURL(x.b);
          var a = document.createElement('a');
          a.href = url;
          a.download = x.name;
          document.body.appendChild(a);
          a.click();
          setTimeout(function () { URL.revokeObjectURL(url); a.remove(); }, 2000);
        })
        .catch(function () { done(); alert('Download failed. Check your internet and try again.'); });
    });
  });

  // QR code for the authenticator app (setup and 2FA reset).
  var q = document.getElementById('qr');
  if (q && window.qrcode) {
    var qr = window.qrcode(0, 'M');
    qr.addData(q.getAttribute('data-uri'));
    qr.make();
    q.innerHTML = qr.createSvgTag({ cellSize: 4, margin: 2, scalable: true });
  }
})();
