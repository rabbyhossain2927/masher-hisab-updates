// Masher Hisab Admin: lets the panel be installed as an app.
// Nothing is cached — admin data always comes fresh from the server.
self.addEventListener('install', () => self.skipWaiting());
self.addEventListener('activate', (e) => e.waitUntil(self.clients.claim()));
self.addEventListener('fetch', () => {});
