<?php
// Only needed when the panel cannot find the masher-api folder by itself.
// Copy to config.local.php (same folder) and put the full path:
return [
    'api_dir' => '/home/YOUR-CPANEL-USER/public_html/masher-api',
];
